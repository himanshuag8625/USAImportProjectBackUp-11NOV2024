﻿namespace USAImportWorkflowWeb.Models
{
    public class FilterDataModel
    {
        public string fileNo { get; set; }
        public string container { get; set; }
        public string userId { get; set; }
        public string office { get; set; }
        public string hblstatus { get; set; }
        public string eta_d { get; set; }
        public string currentStatus { get; set; }
    }
}
