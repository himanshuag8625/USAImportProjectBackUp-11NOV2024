﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Data
{
    public partial class OfficeMaster
    {
        public OfficeMaster()
        {
            UserOfficeMasters = new HashSet<UserOfficeMaster>();
        }

        public Guid Id { get; set; } = Guid.NewGuid();
        public string? Office { get; set; }
        public string? OfficeName { get; set; }
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;

        public virtual ICollection<UserOfficeMaster> UserOfficeMasters { get; set; }


    }
}