﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace USAImportWorkflowWeb.Data
{
    public class QcHblWiseData
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid? QcMasterId { get; set; }
        public string FileNumber { get; set; }
        public string Hblno { get; set; }
        public string ErrorField { get; set; }
        public string ErrorType { get; set; }
        public string Comment { get; set; }
        public string L1comment { get; set; }
        public string L2comment { get; set; }
        public string L3comment { get; set; }
        public string L4comment { get; set; }
        public string QcStatus { get; set; }
        public string Qcuser { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }

        [ForeignKey("QcMasterId")]
        public virtual QcMaster QcMaster { get; set; }
    }
}
