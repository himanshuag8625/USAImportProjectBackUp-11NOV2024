﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class UpdateOfficeModel
    {
        public string? CitrixId { get; set; }
        public Guid? OfficeId { get; set; }
    }
}
