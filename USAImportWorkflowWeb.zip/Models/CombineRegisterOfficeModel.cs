﻿namespace USAImportWorkflowWeb.Models
{
    public class CombineRegisterOfficeModel
    {
        public RegisterViewModel RegisterModel { get; set; }
        public UserOfficeRelationViewModel OfficeRelationModel { get; set; }
        public UserRoleViewModel AssignRole { get; set; }
    }
}
