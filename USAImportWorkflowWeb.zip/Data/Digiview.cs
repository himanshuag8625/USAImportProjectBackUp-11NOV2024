﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Data
{
    public class Digiview
    {
        public string Hblno { get; set; }
        public string UserId { get; set; }
        public string DigiviewStatus { get; set; }
        public string DigiviewComments { get; set; }
        public DateTime? LastModifiedDate { get; set; }

        public virtual UserMaster User { get; set; }
    }
}
