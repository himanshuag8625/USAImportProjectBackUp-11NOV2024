﻿using System.Collections.Generic;
using USAImportWorkflowWeb.Data;

namespace USAImportWorkflowWeb.Models
{
    public class ResetPasswordViewModel
    {
        public IEnumerable<UserMaster> Users { get; set; }
        public string SelectedUserId { get; set; }
    }
}
