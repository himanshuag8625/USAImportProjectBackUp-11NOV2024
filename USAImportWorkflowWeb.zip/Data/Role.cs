﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Data
{
    public partial class Role
    {
        public Role()
        {
            RoleRelation = new HashSet<RoleRelation>();
        }
       
        public int RoleId { get; set; }
        public string Role1 { get; set; }

       
        public virtual ICollection<RoleRelation> RoleRelation { get; set; }
    }
}
