﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Drawing;
using DocumentFormat.OpenXml.InkML;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Security.Claims;
using System.Threading.Tasks;
using USAImportWorkflowWeb.Data;
using USAImportWorkflowWeb.Helper;
using USAImportWorkflowWeb.Models;
using USAImportWorkflowWeb.Views.Admin;
using static System.Net.WebRequestMethods;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;
using Path = System.IO.Path;

namespace USAImportWorkflowWeb.ControllersDa
{
    [Authorize(Roles = "Admin,Manager,Supervisor")]
    public class AdminController : Controller
    {
        private readonly UserManager<UserMaster> userManger;
        private readonly SignInManager<UserMaster> signInManager;
        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IHostingEnvironment hostingEnvironment;
        public AdminController(ApplicationDbContext ctx, IHttpContextAccessor httpContextAccessor, UserManager<UserMaster> userManger, SignInManager<UserMaster> signInManager, IHostingEnvironment _hostingEnvironment)
        {
            userManger = userManger;
            this.signInManager = signInManager;
            hostingEnvironment = _hostingEnvironment;
            _httpContextAccessor = httpContextAccessor;
            _ctx = ctx;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult AdminDashboard(FileMasterViewModel model)
        {
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId


            }).OrderBy(x => x.CitrixId).ToList();
            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            return View(model);
        }

        //Get File Master Datatable  
        public JsonResult GetDashboard(string fileNo, string container, string statusId, string userId,
          string office, string hblstatus, string eta_d)
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            IQueryable<FileMaster> data = _ctx.Set<FileMaster>().AsQueryable();
            IQueryable<UserMaster> udata = _ctx.Set<UserMaster>().AsQueryable();
            //IQueryable<QcMaster> qcdata = _ctx.Set<QcMaster>().AsQueryable();
            IQueryable<OfficeMaster> odata = _ctx.Set<OfficeMaster>().AsQueryable();

            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            int totalRecord = 0;
            int filterRecord = 0;
            //var draw = Request.Form["draw"].FirstOrDefault();
            totalRecord = data.Count();
            string key = "";
            string value = "";
            Boolean searchflag = false;
            Boolean sortflag = false;
            DateTime sixMonths = DateTime.UtcNow.AddMonths(-6);
            IQueryable<FileMasterViewModel> result = Enumerable.Empty<FileMasterViewModel>().AsQueryable();
            result = data.Select(x => new FileMasterViewModel
            {
                FileNumber = x.FileNumber,
                Container = x.Container,
                RecievedDate = x.RecievedDate,
                UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                Hblstatus = x.Hblstatus,
                FileComplitionDate = x.FileComplitionDate,
                Hblcount = x.Hblcount,
                Eta = x.Eta,
                EtaChangedBy = udata.Where(y => y.Wnsid == x.EtaChangedBy).Select(y => y.UserName).First(),
                Office = odata.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                CreateDateTime = x.CreateDateTime,
                PreviousEta = x.PreviousEta,
                EtaChangedDatetime = x.EtaChangedDatetime,
                EtaChangedComment = x.EtaChangedComment,
                QcStatus = x.QcStatus,
                FileType = x.FileType,
                Pol = x.Pol,
                Pod = x.Pod,
                MasterBl = x.MasterBl,
                SSL = x.SSL
            }).AsQueryable();

            //IQueryable<FileMasterViewModel> SortedData = result.AsQueryable();

            //if (!string.IsNullOrEmpty(fileNo))
            //{
            //    SortedData = SortedData.Where(x => x.FileNumber == fileNo);
            //    pageSize = SortedData.Count();
            //}
            //if (!string.IsNullOrEmpty(container))
            //{
            //    SortedData = SortedData.Where(x => x.Container == container);
            //    pageSize = SortedData.Count();
            //}
            //if (!string.IsNullOrEmpty(hblstatus) && hblstatus != "--select--")
            //{
            //    SortedData = SortedData.Where(x => x.Hblstatus == hblstatus);
            //    pageSize = SortedData.Count();
            //}
            //if (!string.IsNullOrEmpty(userId) && userId != "--select--")
            //{
            //    var userName = _ctx.UserMaster.Where(x => x.Id == userId).Select(x => x.UserName).FirstOrDefault();
            //    SortedData = SortedData.Where(x => x.UserId == userName);
            //    pageSize = SortedData.Count();
            //}
            //if (!string.IsNullOrEmpty(office) && office != "--select--")
            //{
            //    SortedData = SortedData.Where(x => x.Office == office);
            //    pageSize = SortedData.Count();
            //}
            //if (!string.IsNullOrEmpty(eta_d))
            //{
            //    SortedData = SortedData.Where(x => x.Eta.Value.Date == Convert.ToDateTime(eta_d).Date);
            //    pageSize = SortedData.Count();
            //}

            //if (!string.IsNullOrEmpty(searchValue))
            //{
            //    if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
            //        searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12" || searchValue == "eta18")
            //    {
            //        if (searchValue == "eta10")
            //        {
            //            SortedData = SortedData.Where(x => x.Eta.Value.Date != null && Convert.ToDateTime(x.Eta).AddDays(-10).Date <= DateTime.Now.Date && (x.Hblstatus != "Completed"));

            //        }
            //        else if (searchValue == "eta12")
            //        {
            //            SortedData = SortedData.Where(x => x.Eta.Value.Date != null && Convert.ToDateTime(x.Eta).AddDays(-10).Date > DateTime.Now.Date && Convert.ToDateTime(x.Eta).AddDays(-12).Date <= DateTime.Now.Date && x.Hblstatus != "Completed");
            //        }
            //        else if (searchValue == "eta18")
            //        {
            //            SortedData = SortedData.Where(x => x.Eta.Value.Date != null && Convert.ToDateTime(x.Eta).AddDays(-12).Date > DateTime.Now.Date && x.Hblstatus != "Completed");
            //        }
            //        else if (searchValue == "UnAllocated")
            //        {
            //            searchValue = null;
            //            SortedData = SortedData.Where(x => x.Hblstatus == searchValue);

            //        }
            //        else
            //        {
            //            SortedData = SortedData.Where(x => x.Hblstatus == searchValue);
            //        }
            //        pageSize = SortedData.Count();
            //    }
            //}
           
            IQueryable<FileMasterViewModel> SortedData = result.Where(x => x.FileComplitionDate.Value.Date >= sixMonths.Date || x.FileComplitionDate == (DateTime?)null).AsQueryable();

            if (!string.IsNullOrEmpty(fileNo))
            {
                SortedData = SortedData.Where(x => x.FileNumber == fileNo);
            }

            if (!string.IsNullOrEmpty(container))
            {
                SortedData = SortedData.Where(x => x.Container == container);
            }

            if (!string.IsNullOrEmpty(hblstatus) && hblstatus != "--select--")
            {
                SortedData = SortedData.Where(x => x.Hblstatus == hblstatus);
            }

            if (!string.IsNullOrEmpty(userId) && userId != "--select--")
            {
                var userName = _ctx.UserMaster.Where(x => x.Id == userId).Select(x => x.UserName).FirstOrDefault();
                if (userName != null)
                {
                    SortedData = SortedData.Where(x => x.UserId == userName);
                }
            }

            if (!string.IsNullOrEmpty(office) && office != "--select--")
            {
                SortedData = SortedData.Where(x => x.Office == office);
            }

            if (!string.IsNullOrEmpty(eta_d) && DateTime.TryParse(eta_d, out var etaDate))
            {
                SortedData = SortedData.Where(x => x.Eta.HasValue && x.Eta.Value.Date == etaDate.Date);
            }

            if (!string.IsNullOrEmpty(searchValue))
            {
                switch (searchValue)
                {
                    case "WIP":
                        SortedData = SortedData.Where(x => x.Hblstatus == searchValue);
                        break;
                    case "Completed":
                        SortedData = SortedData.Where(x => x.Hblstatus == searchValue);
                        break;
                    case "Pending":
                        SortedData = SortedData.Where(x => x.Hblstatus == searchValue);
                        break;
                    case "Query":
                        SortedData = SortedData.Where(x => x.Hblstatus == searchValue);
                        break;
                    case "UnAllocated":
                        SortedData = SortedData.Where(x => x.Hblstatus == "" || x.Hblstatus == null);
                        break;
                    case "eta10":
                        SortedData = SortedData.Where(x => x.Eta.HasValue && x.Eta.Value.Date <= DateTime.Now.Date.AddDays(10) && x.Hblstatus != "Completed");
                        break;
                    case "eta12":
                        SortedData = SortedData.Where(x => x.Eta.HasValue && x.Eta.Value.Date > DateTime.Now.Date.AddDays(10) && x.Eta.Value.Date <= DateTime.Now.Date.AddDays(12) && x.Hblstatus != "Completed");
                        break;
                    case "eta18":
                        SortedData = SortedData.Where(x => x.Eta.HasValue && x.Eta.Value.Date > DateTime.Now.Date.AddDays(12) && x.Eta.Value.Date <= DateTime.Now.Date.AddDays(18) && x.Hblstatus != "Completed");
                        break;
                }
            }

            //pageSize = SortedData.Count();

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                {
                    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
                    //pageSize=SortedData.Count();
                }

                sortflag = false;
            }
            catch { }

            var dashboard = SortedData.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).ToList();

            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = SortedData.Count(),
                data = dashboard,
                skip = skip,
                pageSize = pageSize,
            };
            return Json(returnObj);
        }

        public IActionResult GetUser(UserMasterModel model)
        {
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();
            return View();
        }

        public IActionResult AddUser(RegisterViewModel model)
        {
            ViewData["Roles"] = _ctx.Roles.Select(x => new RoleMasterModel
            {
                Id = x.Id,
                Name = x.Name

            }).OrderBy(x => x.Name).ToList();
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();

            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            return View(model);
        }
        //User Registration
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var user = new UserMaster
                    {
                        CitrixId = model.CitrixId,
                        Wnsid = model.Wnsid,
                        UserName = model.CitrixId,
                        Doc_Contact = model.Doc_Contact
                    };
                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = model.Userrole,
                        UserId = user.Id,
                    });

                    var result = await userManger.CreateAsync(user);
                    _ctx.SaveChanges();
                    if (result.Succeeded)
                    {
                        //await signInManager.SignInAsync(user, false);
                        return RedirectToAction("Login", "Account");
                    }
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }
            catch (Exception)
            {

            }
            return View(model);
        }

        public IActionResult AddOffices()
        {
            ViewData["Office"] = _ctx.OfficeMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.OfficeName).ToList();
            var result = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                Office = x.Office,
                OfficeName = x.OfficeName,
                IsActive = x.IsActive,
                IsDelete = x.IsDelete
            }).Where(x => x.IsDelete == false).OrderBy(x => x.OfficeName).ToList();
            return View(result);
        }
        //Add Office
        [HttpPost]
        public async Task<IActionResult> AddOffices(OfficeMasterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = _ctx.OfficeMaster.Where(x => x.OfficeName == model.OfficeName).FirstOrDefault();
                if (result != null)
                {

                }
                else
                {
                    _ctx.OfficeMaster.Add(new OfficeMaster
                    {
                        Office = model.Office,
                        OfficeName = model.OfficeName,
                        IsActive = true,
                        IsDelete = false

                    });
                    _ctx.SaveChanges();
                }
            }
            return View(model);
        }

        public IActionResult AddUserWiseOfficeRelation()
        {
            ViewData["Roles"] = _ctx.Roles.Select(x => new RoleMasterModel
            {
                Id = x.Id,
                Name = x.Name

            }).OrderBy(x => x.Name).ToList();
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();

            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            ViewData["OfficesRelation"] = _ctx.UserOfficeRelation.Select(x => new UserOfficeRelationViewModel
            {
                Id = x.Id,
                OfficeId = x.OfficeId,
                UserId = x.UserId

            }).ToList();

            return View();
        }
        //Add User Wise Office Relation
        [HttpPost]
        public JsonResult AddUserWiseOfficeRelation([FromBody] AddUserwiseOfficeLocationCS model)
        {
            string Msg = "";
            ViewData["Roles"] = _ctx.Roles.Select(x => new RoleMasterModel
            {
                Id = x.Id,
                Name = x.Name
            }).OrderBy(x => x.Name).ToList();
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();

            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            ViewData["OfficesRelation"] = _ctx.UserOfficeRelation.Select(x => new UserOfficeRelationViewModel
            {
                Id = x.Id,
                OfficeId = x.OfficeId,
                UserId = x.UserId

            }).ToList();

            var found = _ctx.UserOfficeRelation.Where(x => x.UserId == model.UserId && x.Order == Convert.ToInt16(model.Order)).FirstOrDefault();

            if (found == null)
            {
                _ctx.UserOfficeRelation.Add(new UserOfficeRelation
                {
                    //Id =Guid.Parse( model.Id),
                    OfficeId = Guid.Parse(model.OfficeId.ToString()),
                    UserId = model.UserId,
                    IsActive = true,
                    Order = Convert.ToInt16(model.Order)

                });
                _ctx.SaveChanges();
                Msg = "User Office Relation Add";
            }
            else
            {
                var rowsModified = _ctx.Database.ExecuteSqlRaw($"UPDATE [UserOfficeRelation] SET [OfficeId] ='" + model.OfficeId + "',[Order]='" + model.Order + "' WHERE [Id]='" + found.Id + "' and [UserId]='" + model.UserId + "'");
                _ctx.SaveChanges();
                Msg = "User Office Relation Update";

            }

            return Json(Msg);
        }

        public IActionResult AssignRole()
        {
            ViewData["Roles"] = _ctx.Roles.Select(x => new RoleMasterModel
            {
                Id = x.Id,
                Name = x.Name

            }).OrderBy(x => x.Name).ToList();
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();

            return View();
        }

        //Assign Role to User
        [HttpPost]
        public JsonResult AssignRole([FromBody] UserRoleViewModel model)
        {
            string Msg = "";
            ViewData["Roles"] = _ctx.Roles.Select(x => new RoleMasterModel
            {
                Id = x.Id,
                Name = x.Name

            }).OrderBy(x => x.Name).ToList();
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();
            if (model.UserId == "Select")
            {
                Msg = "Please select User";
            }
            else if (model.RoleId == "Select")
            {
                Msg = "Please select Role";
            }
            else
            {
                var urole = _ctx.UserRoles.Where(x => x.UserId == model.UserId);
                if (urole.Count() == 0)
                {
                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = model.RoleId,
                        UserId = model.UserId,
                    });
                    _ctx.SaveChanges();
                    Msg = "User role assign sucessfully.";
                }
                else
                {
                    _ctx.Database.ExecuteSqlRaw($"UPDATE [UserRoles] SET [RoleId] ='" + model.RoleId + "' WHERE [UserId]='" + model.UserId + "'");
                    _ctx.SaveChanges();
                    Msg = "User role change sucessfully.";

                }

            }
            return Json(Msg);
        }

        //Is Login active 
        [HttpPost]
        public JsonResult IsLoginActive([FromBody] IsLoginActiveModel model)
        {
            string Msg = "";
            try
            {
                if (model != null)
                {
                    var wnsid = _ctx.Users.Where(x => x.Wnsid == model.UserId).Select(x => x.Wnsid).SingleOrDefault();
                    UserMaster user = _ctx.UserMaster.Where(x => x.Wnsid == wnsid).FirstOrDefault();
                    Boolean status = Convert.ToBoolean(model.IsActive);
                    if (model.IsActive == false)
                    {
                        user.IsActive = false;
                        Msg = "User is De-Active Update Sucessfully";
                    }
                    else
                    {
                        user.IsActive = true;
                        Msg = "User is Active Update Sucessfully";
                    }
                    _ctx.UserMaster.Update(user);
                    _ctx.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                Msg = ex.Message;
            }
            return Json(Msg);
        }

        //Add File
        public IActionResult Insert_File(string Msg)
        {
            if (Msg == "File Added Successfully!")
            {
                ViewData["Msg"] = Msg;
            }
            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            ViewData["ContactPersonList"] = _ctx.DispositionMaster.Select(x => new ContactPersonModel
            {
                Name = x.Name,
                Code = x.Code

            }).ToList();

            return View();
        }
        //Insert File into Database
        [HttpPost]
        public JsonResult Insert_FileDB([FromBody] InsertFileMaster file)
        {
            string Msg = "";
            try
            {
                var found = _ctx.FileMaster.Where(x => x.FileNumber == file.FileNumber).FirstOrDefault();
                var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                if (found == null)
                {
                    FileMaster FM = new FileMaster
                    {
                        FileNumber = file.FileNumber.Trim(),
                        Container = file.Container.Trim(),
                        Hblcount = file.Hblcount,
                        MasterBl = file.MBLCount,
                        RecievedDate = file.RecievedDate == "" ? null : Convert.ToDateTime(file.RecievedDate),
                        Eta = file.Eta == "" ? null : Convert.ToDateTime(file.Eta),
                        Office = file.Office,
                        UserId = userid,
                        ContactPerson = file.ContactPerson,
                        QcStatus = "",
                        Pol = file.Pol.Trim(),
                        Pod = file.Pod.Trim(),
                        SSL = file.SSL.Trim(),
                        CreateDateTime = DateTime.Now,
                        FileType = file.filetype
                    };
                    var res = _ctx.FileMaster.Add(FM);
                    _ctx.SaveChanges();
                    Msg = "File Insert Successfully!";
                }
                else
                {
                    Msg = "File is already Inserted.";

                }
            }
            catch (Exception ex)
            {

            }
            return Json(Msg);
        }
        //Change File Status
        [HttpPost]
        public JsonResult ChangeStatus([FromBody] FileMasterViewModel file)
        {
            string Msg = "";

            if (file != null)
            {
                var found = _ctx.FileMaster.Include(x => x.Hblmaster).Where(x => x.FileNumber == file.FileNumber).FirstOrDefault();

                if (found != null)
                {
                    if (found.Hblstatus == "Completed" && file.Hblstatus == "Completed")
                    {
                        Msg = "Filestatus already completed.";
                        foreach (var hbl in found.Hblmaster)
                        {
                            hbl.HblprocessingStatus = file.Hblstatus;
                            hbl.HblprocessingDate = DateTime.Now;
                            hbl.Amsstatus = file.Hblstatus;
                            hbl.AmsprocessingDate = DateTime.Now;
                            hbl.InvoicingStatus = file.Hblstatus;
                            hbl.InvoicingDate = DateTime.Now.ToString();

                        }
                        found.QcStatus = "Send to Qc";
                        _ctx.FileMaster.Update(found);
                        _ctx.SaveChanges();
                    }
                    else
                    {
                        if (file.Hblstatus == "Completed")
                        {
                            found.Hblstatus = file.Hblstatus;
                            found.FileComplitionDate = DateTime.Now;
                            found.QcStatus = "Send to Qc";
                        }
                        else
                        {
                            if (found.Hbluser == "" || found.Hbluser == null)
                            {
                                Msg = "File is not allocated";
                            }
                            else
                            {
                                found.Hblstatus = file.Hblstatus;
                                found.FileComplitionDate = DateTime.Now;
                                found.QcStatus = "";
                                found.Icuser = "";
                            }
                        }

                        if (Msg == "File is not allocated")
                        {

                        }
                        else
                        {
                            _ctx.FileMaster.Update(found);
                            _ctx.SaveChanges();

                            foreach (var hbl in found.Hblmaster)
                            {
                                hbl.HblprocessingStatus = file.Hblstatus;
                                hbl.HblprocessingDate = DateTime.Now;
                                hbl.Amsstatus = file.Hblstatus;
                                hbl.AmsprocessingDate = DateTime.Now;
                                hbl.InvoicingStatus = file.Hblstatus;
                                hbl.InvoicingDate = DateTime.Now.ToString();
                            }
                            _ctx.FileMaster.Update(found);
                            _ctx.SaveChanges();
                            Msg = "File status Update Sucessfully";
                        }

                    }

                }
            }
            return Json(Msg);
        }


        //Upload Template for ETA changed

        [HttpPost]
        public IActionResult UploadDataForEta(IFormFile formFile)
        {
            try
            {
                if (formFile != null)
                {
                    var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                    string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                    var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                    var fileName = Path.GetFileName(formFile.FileName);
                    var uploads = Path.Combine(hostingEnvironment.WebRootPath, "uploads");
                    if (!Directory.Exists(uploads))
                        Directory.CreateDirectory(uploads);

                    var filePath = Path.Combine(uploads, fileName);
                    using (var dispose = new FileStream(filePath, FileMode.Create))
                    {
                        formFile.CopyTo(dispose);

                    }
                    DataTable xldata = ExcelFunction.GetDataFromExcel(filePath);
                    xldata.Columns.Add("Status");

                    //DataTable dtt = new DataTable();
                    //dtt.Columns.Add("File#");
                    //dtt.Columns.Add("Container#");
                    //dtt.Columns.Add("Eta#");

                    foreach (DataRow dr in xldata.Rows)
                    {
                        try
                        {
                            FileMaster file = _ctx.FileMaster.Where(x => x.FileNumber == dr[0].ToString()).FirstOrDefault();
                            if (file != null)
                            {
                                if (file.QcStatus != "Completed")
                                {
                                    if (file.Eta.ToString() != "")
                                    {
                                        if (file.Eta == Convert.ToDateTime(dr[2].ToString()).Date)
                                        {
                                            dr[3] = "ETA is Same";
                                        }
                                        else
                                        {
                                            file.PreviousEta = file.Eta;
                                            file.EtaChangedBy = wnsid;
                                            file.EtaChangedDatetime = DateTime.Now;
                                            file.Eta = Convert.ToDateTime(dr[2].ToString()).Date;
                                            _ctx.FileMaster.Update(file);
                                            _ctx.SaveChanges();
                                            dr[3] = "Completed";
                                        }

                                    }
                                    else
                                    {
                                        dr[3] = "File ETA is empty";
                                    }

                                }
                                else
                                {
                                    dr[3] = "ETA is not change because of file QCStatus is Completed ";
                                }
                            }
                            else
                            {
                                dr[3] = "File number is not found";
                            }

                        }
                        catch (Exception ex)
                        {
                            dr[3] = ex.Message;
                        }

                    }

                    // string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        xldata.TableName = "ETAchanged";
                        var wsETAchange = wb.Worksheets.Add(xldata);
                        wsETAchange.Columns().AdjustToContents();
                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"ETA_Report-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("AdminDashboard", "Admin");
        }

        //File Upload Data
        [HttpPost]
        public IActionResult UploadData(IFormFile formFile)
        {
            try
            {
                if (formFile != null)
                {
                    var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                    string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                    var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                    var fileName = Path.GetFileName(formFile.FileName);
                    var uploads = Path.Combine(hostingEnvironment.WebRootPath, "uploads");
                    if (!Directory.Exists(uploads))
                        Directory.CreateDirectory(uploads);

                    var filePath = Path.Combine(uploads, fileName);
                    using (var dispose = new FileStream(filePath, FileMode.Create))
                    {
                        formFile.CopyTo(dispose);

                    }
                    DataTable xldata = ExcelFunction.GetDataFromExcel(filePath);

                    DataTable dtt = new DataTable();
                    dtt.Columns.Add("File#");
                    dtt.Columns.Add("Container#");
                    dtt.Columns.Add("MBL#");
                    dtt.Columns.Add("UnitDisposition");
                    dtt.Columns.Add("DepFile");
                    dtt.Columns.Add("Vessel");
                    dtt.Columns.Add("Terminal");

                    List<Hblmaster> addhbls = new List<Hblmaster>();
                    List<string> disp = _ctx.DispositionMaster.Select(x => x.Name).ToList();
                    List<string> dipfile = _ctx.OfficeMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => x.OfficeName.Replace(Environment.NewLine, String.Empty)).ToList();
                    foreach (DataRow dr in xldata.Rows)
                    {

                        if ((dr["File"].ToString() != "" || dr["File"].ToString() != null) && disp.Contains(dr["UnitDisp"].ToString().ToUpper().Trim()) == true
                            && dipfile.Contains(dr["DepFile"]) == true && dr["Product"].ToString() == "LCL")
                        {
                            var duplicate = _ctx.FileMaster.Where(x => x.FileNumber == dr["File"].ToString().Trim() && (x.Hblstatus != "Completed" || x.Hblstatus == null)).FirstOrDefault();

                            if (duplicate != null)
                            {
                                duplicate.FileNumber = dr["File"].ToString().Trim();
                                duplicate.Container = dr["Cont Nr"].ToString().Trim();
                                duplicate.Pol = dr["POL"].ToString().Trim();
                                duplicate.Pod = dr["POD"].ToString().Trim();
                                duplicate.Mbl = dr["MasterBL"].ToString().Trim();
                                duplicate.UnitDispo = dr["UnitDisp"].ToString().Trim();
                                duplicate.DepFile = dr["DepFile"].ToString().Trim();
                                duplicate.ShippingLine = dr["ShipLine"].ToString().Trim();
                                duplicate.Cfs = dr["Devanning CFS"].ToString().Trim();
                                duplicate.Vessel = dr["Vessel"].ToString().Trim();
                                duplicate.Terminal = dr["Terminal"].ToString().Trim();

                                if (duplicate.Eta != Convert.ToDateTime(dr["Eta"]))
                                {
                                    duplicate.PreviousEta = duplicate.Eta == null ? null : duplicate.Eta;
                                    duplicate.Eta = Convert.ToDateTime(dr["Eta"]);
                                    duplicate.EtaChangedComment = "ETA changed through Web report.";
                                }
                                _ctx.FileMaster.Update(duplicate);

                                var dup = _ctx.Hblmaster.Where(x => x.Hblno == dr["BL"].ToString().Trim()).FirstOrDefault();
                                if (dup == null)
                                {
                                    duplicate.Hblmaster.Add(new Hblmaster
                                    {
                                        FileNumber = dr["File"].ToString().Trim(),
                                        Hblno = dr["BL"].ToString().Trim(),
                                        Pod = dr["POD"].ToString().Trim(),
                                        Pld = dr["POL"].ToString().Trim(),
                                        UserId = userId,
                                        CreateDate = DateTime.Now

                                    });
                                    _ctx.SaveChanges();
                                }
                            }
                            else
                            {
                                DataRow row = dtt.NewRow();
                                row["File#"] = dr["File"].ToString().Trim();
                                row["Container#"] = dr["Cont Nr"].ToString().Trim();
                                row["MBL#"] = dr["MasterBL"].ToString().Trim();
                                row["UnitDisposition"] = dr["UnitDisp"].ToString().Trim();
                                row["DepFile"] = dr["DepFile"].ToString().Trim();
                                row["Vessel"] = dr["Vessel"].ToString().Trim();
                                row["Terminal"] = dr["Terminal"].ToString().Trim();
                                dtt.Rows.Add(row);

                            }
                        }
                    }
                    XLWorkbook wb = new XLWorkbook();
                    wb.Worksheets.Add(dtt, "Report");
                    //wb.SaveAs(System.Windows.Forms.Application.StartupPath + "\\Output\\Report_" + DateTime.Now.ToString("ddMMMyyyy") + "_" + DateTime.Now.ToString("hhmmss") + ".xlsx");

                    // System.Windows.MessageBox.Show("File uploaded successfully  && Report saved on " + System.Windows.Forms.Application.StartupPath + "\\Output\\Report_" + DateTime.Now.ToString("ddMMMyyyy") + "_" + DateTime.Now.ToString("hhmmss") + ".xlsx");

                }
            }
            catch (Exception ex)
            {
            }
            return RedirectToAction("AdminDashboard", "Admin");
        }



        //Get Dashboardvalue
        public JsonResult GetDashboardValue()
        {
            //var draw = Request.Form["draw"].FirstOrDefault();
            //DateTime threeMonths = DateTime.UtcNow.AddMonths(-6);
            //var result = _ctx.FileMaster.ToList();
            IQueryable<FileMaster> data = _ctx.Set<FileMaster>().AsQueryable();
            IQueryable<UserMaster> udata = _ctx.Set<UserMaster>().AsQueryable();
            //IQueryable<QcMaster> qcdata = _ctx.Set<QcMaster>().AsQueryable();
            IQueryable<OfficeMaster> odata = _ctx.Set<OfficeMaster>().AsQueryable();
            IQueryable<FileMasterViewModel> result = Enumerable.Empty<FileMasterViewModel>().AsQueryable();
            DateTime sixMonths = DateTime.UtcNow.AddMonths(-6);
            result = data.Select(x => new FileMasterViewModel
            {
                FileNumber = x.FileNumber,
                Container = x.Container,
                RecievedDate = x.RecievedDate,
                UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                Hblstatus = x.Hblstatus,
                FileComplitionDate = x.FileComplitionDate,
                Hblcount = x.Hblcount,
                Eta = x.Eta,
                EtaChangedBy = udata.Where(y => y.Wnsid == x.EtaChangedBy).Select(y => y.UserName).First(),
                Office = odata.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                CreateDateTime = x.CreateDateTime,
                PreviousEta = x.PreviousEta,
                EtaChangedDatetime = x.EtaChangedDatetime,
                EtaChangedComment = x.EtaChangedComment,
                QcStatus = x.QcStatus,
                FileType = x.FileType,
                Pol = x.Pol,
                Pod = x.Pod,
                MasterBl = x.MasterBl,
                SSL = x.SSL
            }).AsQueryable();

            var today = DateTime.Now.Date;
            var add10Days = today.AddDays(10);
            var add12Days = today.AddDays(12);
            var add18Days = today.AddDays(18);

            IQueryable<FileMasterViewModel> SortedData = result.Where(x => x.FileComplitionDate.Value.Date >= sixMonths.Date || x.FileComplitionDate == (DateTime?)null).AsQueryable();
            var dashboard = SortedData.ToList();
            AdminDashboardModel model = new AdminDashboardModel
            {

                Received = dashboard.Count(),
                Pending = dashboard.Where(x => x.Hblstatus == "Pending").Count(),
                WIP = dashboard.Where(x => x.Hblstatus == "WIP").Count(),
                Query = dashboard.Where(x => x.Hblstatus == "Query").Count(),
                Completed = dashboard.Where(x => x.Hblstatus == "Completed").Count(),
                UnAllocated = dashboard.Where(x => x.Hblstatus == "" || x.Hblstatus == null).Count(),
                eta10 = dashboard.Where(x => x.Eta.HasValue && x.Eta.Value.Date <= add10Days && x.Hblstatus != "Completed").Count(),
                eta12 = dashboard.Where(x => x.Eta.HasValue && x.Eta.Value.Date > add10Days && x.Eta.Value.Date <= add12Days && x.Hblstatus != "Completed" /*&& (x.Hblstatus == null || x.Hblstatus == "WIP")*/).Count(),
                eta18 = dashboard.Where(x => x.Eta.HasValue && x.Eta.Value.Date > add12Days && x.Eta.Value.Date <= add18Days && x.Hblstatus != "Completed" /*&& (x.Hblstatus == null || x.Hblstatus == "WIP")*/).Count(),
            };
            //var jsonString = JsonConvert.SerializeObject(model);
            return Json(model);
        }

        public IActionResult FileEdit(string id)
        {
            FileMasterViewModel _FileMasterViewModel = new FileMasterViewModel();
            if (id != null)
            {
                id = id.Replace('/', ' ').Trim();

                try
                {
                    var result = _ctx.FileMaster.FirstOrDefault(x => x.FileNumber == id);

                    _FileMasterViewModel = new FileMasterViewModel()
                    {
                        FileNumber = result.FileNumber,
                        Container = result.Container,
                        Hblcount = result.Hblcount,
                        RecievedDate = result.RecievedDate,
                        Office = result.Office,
                        Eta = result.Eta,
                        Pod = result.Pod,
                        Pol = result.Pol
                    };

                    ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
                    {
                        Id = x.Id,
                        OfficeName = x.OfficeName

                    }).OrderBy(x => x.OfficeName).ToList();
                }
                catch (Exception ex)
                {

                }
            }
            return View(_FileMasterViewModel);
        }
        //Get all Offices
        public IActionResult getoffices()
        {
            try
            {
                var result = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
                {
                    Id = x.Id,
                    OfficeName = x.OfficeName

                }).OrderBy(x => x.OfficeName).ToList();
                ViewData["offices"] = result;
            }
            catch (Exception ex)
            {

            }
            return View();
        }
        //File Edit Update 
        public JsonResult FileEditUpdate([FromBody] InsertFileMaster model, string id)
        {
            string Msg = "";
            try
            {
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                if (model != null)
                {
                    string ids = _httpContextAccessor.HttpContext.Request.Query["id"];


                    FileMaster file = _ctx.FileMaster.Where(x => x.FileNumber == ids).FirstOrDefault();

                    if ((file.Hblstatus == "Completed" || file.Hblstatus == "Pending") && file.QcStatus == "Completed")
                    {
                        Msg = "File is already " + file.Hblstatus + " So don't changes in file.";
                    }
                    else
                    {
                        if (file.FileNumber == model.FileNumber)
                        {

                            file.Container = model.Container;
                            if (Convert.ToDateTime(file.Eta).Date == Convert.ToDateTime(model.Eta).Date)
                            {

                            }
                            else
                            {
                                file.PreviousEta = file.Eta;
                                file.Eta = Convert.ToDateTime(model.Eta);
                                file.NewEta = Convert.ToDateTime(model.Eta);
                                file.EtaChangedBy = wnsid;
                                file.EtaChangedDatetime = DateTime.Now;
                            }
                            file.RecievedDate = Convert.ToDateTime(model.RecievedDate);
                            file.Hblcount = model.Hblcount;
                            file.Office = model.Office;
                            file.Pod = model.Pod;
                            file.Pol = model.Pol;
                            file.FileType = model.filetype;

                            _ctx.FileMaster.Update(file);
                            _ctx.SaveChanges();
                            Msg = "file update sucessfully";
                        }
                        else
                        {
                            //string storedproc = "exec UpdateFileMaster "+
                            //               "@FileNumber='"+model.FileNumber+"'," +
                            //               "@Pod='"+model.Pod+"'," +
                            //               "@Pol='"+model.Pol+"'," +
                            //               "@Hblcount='"+model.Hblcount+"'," +
                            //               "@Container='"+model.Container+"'," +                                          
                            //               "@RecievedDate='"+model.RecievedDate+"'," +
                            //               "@Eta='"+model.Eta +"'," +
                            //               "@Office='"+model.Office+"'," +
                            //               "@PriviousFileno='"+id+"'";

                            //_ctx.FileMaster.FromSqlRaw(storedproc).ToListAsync();

                            var rowsModified = _ctx.Database.ExecuteSqlRaw($"UPDATE [FileMaster] SET [FileNumber] ='" + model.FileNumber + "',[Hblcount]='" + model.Hblcount + "',[Container]='" + model.Container + "',[Pod]='" + model.Pod + "',[Pol]='" + model.Pol + "',[RecievedDate]='" + model.RecievedDate + "',[Eta]='" + model.Eta + "',[Office]='" + model.Office + "' WHERE [FileNumber]='" + id + "'");
                            _ctx.SaveChanges();
                            if (rowsModified == 1)
                            {
                                Msg = "file update sucessfully";
                            }
                            else
                            {
                                Msg = "file is not update";
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return Json(Msg);
        }

        [HttpPost]
        public IActionResult FileUpdate(FileMasterViewModel model)
        {
            try
            {
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                if (model != null)
                {
                    FileMaster file = _ctx.FileMaster.Where(x => x.FileNumber == model.FileNumber || x.Container == model.Container).FirstOrDefault();


                    if (file.Eta == model.Eta)
                    {

                    }
                    else
                    {
                        file.PreviousEta = file.Eta;
                        file.Eta = model.Eta;
                        file.NewEta = model.Eta;
                        file.EtaChangedBy = wnsid;
                        file.EtaChangedDatetime = DateTime.Now;
                    }

                    file.RecievedDate = model.RecievedDate;
                    file.Hblcount = model.Hblcount;
                    file.Office = model.Office;
                    file.Pod = model.Pod.Trim();
                    file.Pol = model.Pol.Trim();

                    _ctx.FileMaster.Update(file);
                    _ctx.SaveChanges();

                }
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("AdminDashboard", "Admin");
        }
        //File Allocate to User
        [HttpPost]
        public JsonResult FileAllocate([FromBody] FileMasterViewModel model)
        {
            string Msg = "";
            try
            {
                var userid = _ctx.Users.Where(x => x.Id == model.UserId).Select(x => x.Wnsid).FirstOrDefault();
                var fileno = _ctx.FileMaster.Where(x => x.FileNumber == model.FileNumber).FirstOrDefault();
                if (fileno != null)
                {
                    fileno.Hblstatus = "WIP";
                    fileno.Hbluser = userid;
                }
                _ctx.FileMaster.Update(fileno);
                _ctx.SaveChanges();
                Msg = "File is allocated to " + userid;
            }
            catch (Exception ex)
            {

            }
            return Json(Msg);
        }

        public IActionResult fileDeAllocate(string Filenumber)
        {
            try
            {
                var fileno = _ctx.FileMaster.Where(x => x.FileNumber == Filenumber).FirstOrDefault();
                if (fileno != null)
                {
                    fileno.Hblstatus = null;
                    fileno.Hbluser = null;
                    fileno.FileStartTime = null;
                    fileno.FileComplitionDate = null;
                    fileno.QcStatus = null;
                    fileno.Icuser = null;
                }
                _ctx.FileMaster.Update(fileno);
                _ctx.SaveChanges();
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("AdminDashboard", "Admin");
        }

        [HttpPost]
        public List<OfficeMaster> GetCountriesName()
        {
            var lst = _ctx.OfficeMaster.Select(x => new OfficeMaster
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();
            return lst;
        }
        //Insert Role
        [HttpPost]
        public IActionResult Insert_Role(RoleMasterModel model)
        {
            var found = _ctx.Roles.Select(x => x.Name == model.Name).FirstOrDefault();

            if (found == false)
            {
                RoleMasterModel role = new RoleMasterModel();

                role.Name = model.Name;

                _ctx.Roles.Add(new IdentityRole() { Id = role.Id, Name = role.Name });
                _ctx.SaveChanges();
                model = new RoleMasterModel();
            }

            return View(model);
        }

        public IActionResult Insert_Role()
        {
            return View();
        }

        //Pre-Alert
        public IActionResult PreAlert(PreAlertMasterViewModel model)
        {
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();
            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            return View(model);
        }
        //PreAlert Upload Data
        [HttpPost]
        public IActionResult PreUploadData(IFormFile formFile)
        {
            try
            {
                if (formFile != null)
                {
                    var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                    string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                    var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                    var fileName = Path.GetFileName(formFile.FileName);
                    var uploads = Path.Combine(hostingEnvironment.WebRootPath, "uploads");
                    if (!Directory.Exists(uploads))
                        Directory.CreateDirectory(uploads);

                    var filePath = Path.Combine(uploads, fileName);
                    using (var dispose = new FileStream(filePath, FileMode.Create))
                    {
                        formFile.CopyTo(dispose);

                    }
                    DataTable xldata = ExcelFunction.GetDataFromExcel(filePath);

                    foreach (DataRow dr in xldata.Rows)
                    {
                        PreAlertMaster duplicate = _ctx.PreAlertMaster.Where(x => x.Container == dr["Container"].ToString().Trim()).FirstOrDefault();

                        if (duplicate != null)
                        {

                        }
                        else
                        {
                            PreAlertMaster preAlert = new PreAlertMaster();
                            //string id = Guid.NewGuid().ToString();
                            preAlert.Id = Guid.NewGuid();
                            preAlert.UserId = userid;
                            if (dr["RecievedDate"].ToString() != "")
                            {
                                if (dr["RecievedDate"].ToString() != null)
                                {
                                    preAlert.RecievedDate = Convert.ToDateTime(dr["RecievedDate"].ToString());
                                }

                            }
                            preAlert.FileNumber = dr["FileNumber"].ToString().Trim() == null ? "-" : dr["FileNumber"].ToString();
                            preAlert.Remarks = dr["Remark"].ToString().Trim();
                            preAlert.CreatedDate = DateTime.Now;
                            preAlert.ComplitionTime = DateTime.Now;
                            preAlert.Office = dr["Office"].ToString().Trim();
                            preAlert.Priority = dr["Priority"].ToString().Trim();
                            preAlert.Container = dr["Container"].ToString();
                            preAlert.Status = dr["Status"].ToString();
                            _ctx.PreAlertMaster.Add(preAlert);
                            _ctx.SaveChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return RedirectToAction("PreAlert", "Admin");
        }

        //Get Prealert Data
        public JsonResult GetPreAlert()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[1][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            IQueryable<PreAlertMaster> data = _ctx.Set<PreAlertMaster>().AsQueryable();
            int totalRecord = 0;
            int filterRecord = 0;
            //DateTime threeMonth = DateTime.UtcNow.AddMonths(-6);
            totalRecord = data.Count();
            string key = "";
            string value = "";

            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();

            if (!string.IsNullOrEmpty(searchValue))
            {
                string searchstring = "";
                foreach (string search in searchValue.Split('|', StringSplitOptions.RemoveEmptyEntries).ToList())
                {
                    if (search == "UnAllocated" || search == "Data Entry" || search == "Pending" || search == "Received" || search == "Missing")
                    {
                        searchValue = search;
                    }
                    else
                    {
                        key = search.Split('_')[0];
                        value = search.Split('_')[1];

                        if (key == "Container")
                        {
                            if (value != "")
                                searchstring = searchstring + key + "=" + '"' + value + '"' + " && ";

                        }
                        else if (key == "Eta")
                        {
                            if (value != "")
                                searchstring = searchstring + key + "=" + '"' + Convert.ToDateTime(value) + '"' + " && ";
                        }
                        else if (key == "Status")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + ".Contains" + '(' + '"' + value + '"' + ')' + " && ";
                        }
                        else if (key == "Office")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + ".Contains" + '(' + '"' + value + '"' + ')' + " && ";
                        }
                    }
                }
                if (searchstring != "")
                {
                    searchstring = searchstring.Trim().Substring(0, searchstring.Length - 3);
                    data = data.Where(searchstring.Trim());
                }
            }
            try
            {
                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            List<PreAlertMasterViewModel> result = new List<PreAlertMasterViewModel>();
           
            if (searchValue == "Data Entry" || searchValue == "UnAllocated" || searchValue == "Missing" || searchValue == "Pending")
            {
                if (searchValue == "eta10")
                {
                    result = data.Where(x => x.Eta.Value.AddDays(-10) <= DateTime.Now && (x.Status == null || x.Status == "")).Select(x => new PreAlertMasterViewModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Wnsid == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Status = x.Status,
                        Mbl = x.Mbl,
                        ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        Priority = x.Priority,
                        Remarks = x.Remarks,
                        FuserId = _ctx.Users.Where(y => y.Id == x.FuserId).Select(y => y.UserName).FirstOrDefault(),
                    }).ToList();
                }
                else if (searchValue == "UnAllocated")
                {
                    result = data.Where(x => x.Status == null || x.Status == "").Select(x => new PreAlertMasterViewModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Status = x.Status,
                        Mbl = x.Mbl,
                        ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        Priority = x.Priority,
                        Remarks = x.Remarks,
                        FuserId = _ctx.Users.Where(y => y.Id == x.FuserId).Select(y => y.UserName).FirstOrDefault(),
                    }).ToList();

                }
                else
                {
                    result = data.Where(x => x.Status == searchValue).Select(x => new PreAlertMasterViewModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Status = x.Status,
                        Mbl = x.Mbl,
                        ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        Priority = x.Priority,
                        Remarks = x.Remarks,
                        FuserId = _ctx.Users.Where(y => y.Id == x.FuserId).Select(y => y.UserName).FirstOrDefault(),
                    }).ToList();
                }
            }
            else
            {
                result = data.Select(x => new PreAlertMasterViewModel
                {
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    RecievedDate = x.RecievedDate,
                    UserId = _ctx.Users.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                    Status = x.Status,
                    Mbl = x.Mbl,
                    ComplitionTime = x.ComplitionTime,
                    Hblcount = x.Hblcount,
                    Pol = x.Pol,
                    Pod = x.Pod,
                    Eta = x.Eta,
                    Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                    Priority = x.Priority,
                    Remarks = x.Remarks,
                    FuserId = _ctx.Users.Where(y => y.Id == x.FuserId).Select(y => y.UserName).FirstOrDefault(),
                }).ToList();
            }
            filterRecord = result.Count();
            //result = result.Where(x => x.RecievedDate != null && x.RecievedDate.Value.Date >= threeMonth.Date).ToList();

            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).ToList();
            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = filterRecord,
                data = result.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).ToList()
            };
            return Json(returnObj);
        }

        public IActionResult Insert_PreAlert()
        {
            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            ViewBag.Message1 = string.Empty;

            ViewData["ContactPersonList"] = _ctx.DispositionMaster.Select(x => new ContactPersonModel
            {
                Name = x.Name,
                Code = x.Code
            }).ToList();
            return View();
        }

        //Insert Prealert
        [HttpPost]
        public IActionResult Insert_PreAlert(PreAlertMaster preAlert)
        {
            try
            {
                var found = _ctx.FileMaster.Where(x => x.FileNumber == preAlert.FileNumber).FirstOrDefault();
                var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();

                string SaveFileFeedback = "";
                string Msg = "";
                var result = _ctx.PreAlertMaster.Where(x => x.Container == preAlert.Container).FirstOrDefault();

                if (result == null)
                {
                    if (preAlert.Container == null || preAlert.RecievedDate == null)
                    {
                        SaveFileFeedback = "Container or Received Date should not be blank.!";
                    }
                    //else if(preAlert.Status=="--select--")
                    //{
                    //    SaveFileFeedback="Please select status.";
                    //}
                    //else if (preAlert.Priority=="--select--")
                    //{

                    //    SaveFileFeedback="Please select  priority.";
                    //}
                    //else if (preAlert.Office=="--select--")
                    //{
                    //    SaveFileFeedback="Please select office.";
                    //}
                    else
                    {
                        if (result == null)
                        {
                            preAlert.Id = Guid.NewGuid();
                            preAlert.UserId = userid;
                            preAlert.CreatedDate = DateTime.Now;
                            preAlert.ComplitionTime = DateTime.Now;
                            preAlert.Status = preAlert.Status;
                            if (preAlert.Priority == "--select--")
                            {
                                preAlert.Priority = "";
                            }
                            if (preAlert.Office == "--select--")
                            {
                                preAlert.Office = "";
                            }

                            _ctx.PreAlertMaster.Add(preAlert);
                            _ctx.SaveChanges();
                            SaveFileFeedback = "Pre-Alert added successfully!";
                        }
                        else
                        {
                            SaveFileFeedback = "Container Already present.!";
                        }
                    }
                }
                else
                {
                    FileMaster fmaster;
                    if (result != null)
                    {
                        if (preAlert.Status == "Data Entry")
                        {
                            result.FuserId = userid;
                            result.Eta = preAlert.Eta;
                            result.Status = preAlert.Status;
                            result.FileNumber = preAlert.FileNumber;
                            result.Hblcount = preAlert.Hblcount;
                            result.Pol = preAlert.Pol;
                            result.Pod = preAlert.Pod;
                            result.Office = preAlert.Office;
                            result.RecievedDate = preAlert.RecievedDate;


                            if (preAlert.Priority == "--select--")
                            {
                                result.Priority = "";
                            }
                            else
                            {
                                result.Priority = preAlert.Priority;
                            }

                            if (preAlert.Office == "--select--")
                            {
                                result.Office = "";
                            }
                            else
                            {
                                result.Office = preAlert.Office;
                            }
                            result.Remarks = preAlert.Remarks;


                            _ctx.PreAlertMaster.Update(result);
                            _ctx.SaveChanges();
                            int days = (int)Math.Round((Convert.ToDateTime(result.Eta) - DateTime.Now).TotalDays);
                            if (days < 0)
                            {
                                Msg = Convert.ToDateTime(result.Eta).ToShortDateString() + " Backdated ETA Inserted..Please check..!";
                            }
                            else
                            {
                                fmaster = new FileMaster
                                {
                                    FileNumber = result.FileNumber,
                                    Container = result.Container,
                                    Pod = result.Pod,
                                    Pol = result.Pol,
                                    Mbl = result.Mbl,
                                    Hblcount = result.Hblcount,
                                    Eta = result.Eta,
                                    Office = result.Office,
                                    RecievedDate = result.RecievedDate,
                                    FileType = result.FileType,
                                    ContactPerson = result.ContractPerson,
                                    CreateDateTime = result.CreatedDate,
                                    UserId = result.UserId
                                };
                                var result1 = _ctx.FileMaster.Where(x => x.FileNumber == fmaster.FileNumber).FirstOrDefault();
                                if (result1 == null)
                                {
                                    _ctx.FileMaster.Add(fmaster);
                                    _ctx.SaveChanges();
                                    SaveFileFeedback = "File " + " " + preAlert.FileNumber + " " + " Created successfully.!";
                                    preAlert = new PreAlertMaster() { Eta = DateTime.Now };
                                    // LstPreAlertFileMaster = new ObservableCollection<PreAlertMaster>(_ctx.PreAlertMaster.Where(x => x.Status == "Pending").OrderBy(x => x.RecievedDate).ToList());
                                }
                                else
                                {
                                    Msg = ("File already present.!");
                                }
                            }
                        }
                        else
                        {
                            //result.UserId =userid;
                            result.FuserId = userid;
                            result.Eta = preAlert.Eta;
                            result.Status = preAlert.Status;
                            result.FileNumber = preAlert.FileNumber;
                            result.Hblcount = preAlert.Hblcount;
                            result.Pol = preAlert.Pol;
                            result.Pod = preAlert.Pod;
                            result.RecievedDate = preAlert.RecievedDate;

                            if (preAlert.Priority == "--select--")
                            {
                                result.Priority = "";
                            }
                            else
                            {
                                result.Priority = preAlert.Priority;
                            }

                            if (preAlert.Office == "--select--")
                            {
                                result.Office = "";
                            }
                            else
                            {
                                result.Office = preAlert.Office;
                            }
                            result.Remarks = preAlert.Remarks;
                            result.ComplitionTime = DateTime.UtcNow;

                            _ctx.PreAlertMaster.Update(result);
                            _ctx.SaveChanges();
                            SaveFileFeedback = "Container " + " " + preAlert.Container + " " + " Updated successfully.!";
                        }
                    }
                    else
                    {
                        result.RecievedDate = preAlert.RecievedDate;
                        result.Container = preAlert.Container;
                        result.Pod = preAlert.Pod;
                        result.Pol = preAlert.Pol;
                        result.Mbl = preAlert.Mbl;
                        result.Hblcount = preAlert.Hblcount;
                        result.Eta = preAlert.Eta;
                        //result.Office = CurrentLocSelection.LocationName;
                        result.ContractPerson = preAlert.ContractPerson;
                        result.MissDocReceivedDate = preAlert.MissDocReceivedDate;
                        //result.AmsCheck = PreAlertMaster.AmsCheck;
                        //result.IfsCheck = PreAlertMaster.IfsCheck;
                        //result.HazDoc = PreAlertMaster.HazDoc;

                        if (preAlert.Priority == "--select--")
                        {
                            result.Priority = "";
                        }
                        else
                        {
                            result.Priority = preAlert.Priority;
                        }

                        result.PieceCount = preAlert.PieceCount;
                        result.Remarks = preAlert.Remarks;
                        //result.ChecklistComplitionDate = PreAlertMaster.ChecklistComplitionDate;
                        //result.UserId = userid;
                        result.FuserId = userid;
                        result.UpdationTime = DateTime.Now;
                        result.Status = preAlert.Status;
                        result.ComplitionTime = DateTime.UtcNow;
                        _ctx.PreAlertMaster.Update(result);
                        _ctx.SaveChanges();
                        SaveFileFeedback = "Container " + " " + preAlert.Container + " " + " Updated successfully.!";
                    }
                }
                ViewBag.Message = SaveFileFeedback;
                ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
                {
                    Id = x.Id,
                    OfficeName = x.OfficeName

                }).OrderBy(x => x.OfficeName).ToList();

                ViewData["ContactPersonList"] = _ctx.DispositionMaster.Select(x => new ContactPersonModel
                {
                    Name = x.Name,
                    Code = x.Code
                }).ToList();
            }
            catch (Exception ex)
            {

            }
            return View();
        }

        //Pre-Alert Edit
        public IActionResult PreAlertEdit(string id)
        {
            PreAlertMasterViewModel _PreAlertMasterViewModel = new PreAlertMasterViewModel();
            try
            {
                var result = _ctx.PreAlertMaster.FirstOrDefault(x => x.Container == id);
                _PreAlertMasterViewModel = new PreAlertMasterViewModel()
                {
                    FileNumber = result.FileNumber,
                    Container = result.Container,
                    Hblcount = result.Hblcount,
                    RecievedDate = result.RecievedDate,
                    Office = result.Office,
                    Eta = result.Eta,
                    Status = result.Status,
                    Pol = result.Pol,
                    Pod = result.Pod,
                    ContractPerson = result.ContractPerson,
                    FileType = result.FileType,
                    UserId = result.UserId,
                    Remarks = result.Remarks,
                    Priority = result.Priority

                };

                ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
                {
                    Id = x.Id,
                    OfficeName = x.OfficeName

                }).OrderBy(x => x.OfficeName).ToList();
                ViewBag.Message = null;
                ViewData["ContactPersonList"] = _ctx.DispositionMaster.Select(x => new ContactPersonModel
                {
                    Name = x.Name,
                    Code = x.Code
                }).ToList();

            }
            catch (Exception ex)
            {

            }
            return View(_PreAlertMasterViewModel);
        }

        //Pre Alert Update
        [HttpPost]
        public IActionResult PreAlertUpdate(PreAlertMasterViewModel model)
        {
            try
            {
                var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();

                PreAlertMaster PAM = _ctx.PreAlertMaster.First(x => x.Container == model.Container);
                PAM.Hblcount = model.Hblcount;
                PAM.Container = model.Container;
                PAM.Eta = model.Eta;
                PAM.RecievedDate = model.RecievedDate;
                PAM.Hblcount = model.Hblcount;
                PAM.Office = model.Office;
                PAM.FuserId = userid;
                PAM.Status = model.Status;
                PAM.ContractPerson = model.ContractPerson;
                PAM.Remarks = model.Remarks;
                PAM.Priority = model.Priority;
                PAM.Pol = model.Pol;
                PAM.Pod = model.Pod;
                PAM.ComplitionTime = DateTime.Now;
                PAM.UpdationTime = DateTime.Now;
                _ctx.PreAlertMaster.Update(PAM);
                _ctx.SaveChanges();
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("PreAlert", "Admin", "File Added Successfully!");
        }

        public JsonResult GetPreAlertDashboard()
        {
            var result = _ctx.PreAlertMaster.ToList();
            PreAlertDashboard model = new PreAlertDashboard
            {
                Received = result.Count,
                Pending = result.Where(x => x.Status == "Pending").ToList().Count,
                UnAllocated = result.Where(x => x.Status == "" || x.Status == null).ToList().Count,
                DataEntry = result.Where(x => x.Status == "Data Entry").ToList().Count,
                Missing = result.Where(x => x.Status == "Missing").ToList().Count
            };
            return Json(model);
        }

        //File Allocate to User
        [HttpPost]
        public JsonResult preAlertFileAllocate([FromBody] PreAlertMasterViewModel model)
        {
            string Msg = "";
            try
            {
                //var userid = _ctx.Users.Where(x => x.Id == model.UserId).Select(x => x.id).FirstOrDefault();
                var fileno = _ctx.PreAlertMaster.Where(x => x.Container == model.Container).FirstOrDefault();
                if (fileno != null)
                {
                    fileno.Status = "Pending";
                    fileno.FuserId = model.UserId;
                }
                _ctx.PreAlertMaster.Update(fileno);
                _ctx.SaveChanges();
                Msg = "File is allocated to " + model.UserId;
            }
            catch (Exception ex)
            {

            }
            return Json(Msg);
        }
        //PreAlert DeAllocation files
        public IActionResult preAlertfileDeAllocate(string Container)
        {
            try
            {
                var fileno = _ctx.PreAlertMaster.Where(x => x.Container == Container).FirstOrDefault();
                if (fileno != null)
                {
                    fileno.FuserId = null;
                    fileno.Status = null;
                    fileno.ComplitionTime = null;
                }
                _ctx.PreAlertMaster.Update(fileno);
                _ctx.SaveChanges();
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("PreAlert", "Admin");
        }




        //TracknTrace Module
        public IActionResult TracknTrace(TrackNTaceReportModel model)
        {
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();

            return View(model);
        }

        public JsonResult GetTrackTrace()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            IQueryable<FileMaster> data = _ctx.Set<FileMaster>().AsQueryable();
            int totalRecord = 0;
            int filterRecord = 0;
            //var draw = Request.Form["draw"].FirstOrDefault();
            totalRecord = data.Count();
            string key = "";
            string value = "";
            //DateTime threeMonths = DateTime.UtcNow.AddDays(-6);
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();

            if (!string.IsNullOrEmpty(searchValue))
            {
                string searchstring = "";
                foreach (string search in searchValue.Split('|', StringSplitOptions.RemoveEmptyEntries).ToList())
                {
                    if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" || search == "Received" || search == "eta10" || search == "eta12" ||
                        search == "eta18")
                    {
                        searchValue = search;
                    }
                    else
                    {
                        key = search.Split('_')[0];
                        value = search.Split('_')[1];

                        if (key == "FileNumber")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + "=" + '"' + value + '"' + " && ";

                        }
                        else if (key == "Eta")
                        {
                            if (value != "")
                                searchstring = searchstring + key + "=" + '"' + Convert.ToDateTime(value) + '"' + " && ";
                        }
                        else if (key == "Office")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + ".Contains" + '(' + '"' + value + '"' + ')' + " && ";
                        }
                    }
                }
                if (searchstring != "")
                {
                    searchstring = searchstring.Trim().Substring(0, searchstring.Length - 3);
                    data = data.Where(searchstring.Trim());
                }
            }
            try
            {
                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            List<TrackNTaceReportModel> result = new List<TrackNTaceReportModel>();

            if (searchValue == "Completed" || searchValue == "WIP" || searchValue == "Query" || searchValue == "Pending" || searchValue == "eta10" || searchValue == "eta12"
                || searchValue == "eta18")
            {
                if (searchValue == "eta10")
                {
                    result = data.Where(x => x.Eta.Value.AddDays(-10) <= DateTime.Now && (x.Hblstatus == null || x.Hblstatus == "WIP")).Select(x => new TrackNTaceReportModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Wnsid == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        Mbl = x.Mbl,
                        //ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        FileType = ""
                    }).ToList();
                }
                else
                {
                    result = data.Where(x => x.Hblstatus == searchValue).Select(x => new TrackNTaceReportModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Wnsid == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        Mbl = x.Mbl,
                        //ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        FileType = ""
                    }).ToList();
                }
            }
            else
            {
                result = data.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).Select(x => new TrackNTaceReportModel
                {
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    RecievedDate = x.RecievedDate,
                    UserId = _ctx.Users.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                    Hblstatus = x.Hblstatus,
                    Mbl = x.Mbl,
                    FileComplitionDate = x.FileComplitionDate,
                    Hblcount = x.Hblcount,
                    Pol = x.Pol,
                    Pod = x.Pod,
                    Eta = x.Eta,
                    Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                    FileType = "",
                    EtaChangedBy = _ctx.Users.Where(y => y.Wnsid == x.EtaChangedBy).Select(y => y.UserName).FirstOrDefault(),
                    EtaChangedComment = x.EtaChangedComment,
                    EtaChangedDatetime = x.EtaChangedDatetime,
                    CreateDateTime = x.CreateDateTime
                }).Where(x => x.Hblstatus == null).ToList();

            }
            filterRecord = data.Count();
            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = filterRecord,
                data = result.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).ToList()
            };

            return Json(returnObj);
        }

        public ActionResult TrackTraceFileEdit(string id)
        {
            id = id.Replace('/', ' ').Trim();
            TrackNTaceReportModel _TrackNTaceReportModel = new TrackNTaceReportModel();
            try
            {
                var result = _ctx.FileMaster.FirstOrDefault(x => x.FileNumber == id);
                _TrackNTaceReportModel = new TrackNTaceReportModel()
                {
                    FileNumber = result.FileNumber,
                    Container = result.Container,
                    Hblcount = result.Hblcount,
                    RecievedDate = result.RecievedDate,
                    Office = result.Office,
                    Eta = result.Eta,
                    Hblstatus = result.Hblstatus,
                    Pol = result.Pol,
                    Pod = result.Pod,
                    FileType = result.FileType,
                    UserId = result.UserId,
                    TrackNtraceUserId = result.UserId
                };

                ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
                {
                    Id = x.Id,
                    OfficeName = x.OfficeName

                }).OrderBy(x => x.OfficeName).ToList();
            }
            catch (Exception ex)
            {
            }
            return View(_TrackNTaceReportModel);
        }

        [HttpPost]
        public IActionResult TrackTraceUpdate(TrackNTaceReportModel model)
        {
            try
            {
                var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();

                var file = _ctx.FileMaster.Where(x => x.FileNumber == model.FileNumber).FirstOrDefault();
                file.PreviousEta = file.Eta;
                file.Eta = model.Eta;
                file.EtaChangedBy = wnsid;
                file.EtaChangedDatetime = DateTime.Now;
                file.TrackNtraceUserId = userid;
                file.EtaChangedComment = "Eta Changed";
                _ctx.FileMaster.Update(file);
                _ctx.SaveChanges();
            }
            catch (Exception ex)
            {
            }
            return RedirectToAction("TracknTrace", "Admin");
        }

        //Report Download
        public ActionResult Report()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Report(ReportViewModel report)
        {
            //do not change below code.If you want to change please discuss with Vaibhav Aher
            TimeZoneInfo istTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");

            if (report.ReportType == "PreAlert")
            {
                if (report.start_date != null && report.end_date != null)
                {
                    IQueryable<UserMaster> udata = _ctx.Set<UserMaster>().AsQueryable();
                    //DateTime Startdate = Convert.ToDateTime(report.start_date.ToString("MM/dd/yyyy"));
                    //DateTime enddate = Convert.ToDateTime(report.end_date.ToString("MM/dd/yyyy"));
                    DateTime Startdate = report.start_date;
                    DateTime enddate = report.end_date;
                    DataTable preAlertDT = new DataTable();
                    preAlertDT.Columns.Add("File Number");
                    preAlertDT.Columns.Add("Container");
                    preAlertDT.Columns.Add("Mbl");
                    preAlertDT.Columns.Add("HBLcount");
                    preAlertDT.Columns.Add("Pod");
                    preAlertDT.Columns.Add("Pol");
                    preAlertDT.Columns.Add("ReceivedDate");
                    preAlertDT.Columns.Add("ReceivedDate(IST)");
                    preAlertDT.Columns.Add("Eta");
                    preAlertDT.Columns.Add("Status");
                    preAlertDT.Columns.Add("Priority");
                    preAlertDT.Columns.Add("Remark");
                    preAlertDT.Columns.Add("CompletionTime");
                    preAlertDT.Columns.Add("CompletionTime(IST)");
                    preAlertDT.Columns.Add("UserId");
                    preAlertDT.Columns.Add("Allocated");
                    preAlertDT.Columns.Add("CreateDate");
                    preAlertDT.Columns.Add("CreateDate(IST)");
                    preAlertDT.Columns.Add("Production Date");

                    //do not change below code.If you want to change please discuss with Vaibhav Aher
                    var preAlertResult = _ctx.PreAlertMaster
                        .Where(x => x.ComplitionTime.Value.Date >= Startdate.Date && x.ComplitionTime.Value.Date <= enddate.Date)
                        .Select(x => new Models.PreAlertMasterReport
                        {
                            FileNumber = x.FileNumber.Trim(),
                            Container = x.Container.Trim(),
                            Mbl = x.Mbl.Trim(),
                            Hblcount = x.Hblcount,
                            Pod = x.Pod.Trim(),
                            Pol = x.Pol.Trim(),
                            RecievedDate = x.RecievedDate,
                            ReceivedDateIST = x.RecievedDate.HasValue
                                ? TimeZoneInfo.ConvertTimeFromUtc(x.RecievedDate.Value, istTimeZone).ToString()
                                : string.Empty,
                            Eta = x.Eta,
                            Status = x.Status.Trim(),
                            Priority = x.Priority.Trim(),
                            Remarks = x.Remarks.Trim(),
                            ComplitionTime = x.ComplitionTime,
                            CompletionIST = x.ComplitionTime.HasValue
                                ? TimeZoneInfo.ConvertTimeFromUtc(x.ComplitionTime.Value, istTimeZone).ToString()
                                : string.Empty,
                            CreatedDate = x.CreatedDate,
                            CreatedDateIST = x.CreatedDate.HasValue
                                ? TimeZoneInfo.ConvertTimeFromUtc(x.CreatedDate.Value, istTimeZone).ToString()
                                : string.Empty,
                            ProductionDate = x.ComplitionTime.HasValue
                                ? x.ComplitionTime.Value.ToShortDateString()
                                : string.Empty,
                            UserId = (from u in udata where u.Id == x.UserId select u.Doc_Contact).FirstOrDefault(),
                            FuserId = (from u in udata where u.Id == x.FuserId select u.Doc_Contact).FirstOrDefault()
                        })
                        .ToList();

                    DataTable preAlertDTT = ToDataTable(preAlertResult);

                    foreach (DataRow item in preAlertDTT.Rows)
                    {
                        DataRow dr = preAlertDT.NewRow();
                        for (int i = 0; i < preAlertDTT.Columns.Count; i++)
                        {
                            dr[i] = item[i];

                        }
                        preAlertDT.Rows.Add(dr);
                    }

                    string filename = "";
                    //filename = saveFile.FileName;
                    string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        preAlertDT.TableName = "PreAlert Data";
                        var wsFileData = wb.Worksheets.Add(preAlertDT);
                        wsFileData.Columns().AdjustToContents();

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"PreAlertCreationReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }

                            // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }

            //do not change below code.If you want to change please discuss with Vaibhav Aher

            else if (report.ReportType == "Qc")
            {
                //do not change below code.If you want to change please discuss with Vaibhav Aher

                IQueryable<UserMaster> udata = _ctx.Set<UserMaster>().AsQueryable();

                if (report.start_date != null && report.end_date != null)
                {

                    DateTime Startdate = report.start_date;
                    DateTime enddate = report.end_date;
                    //var Startdate = report.start_date.ToString("yyyy-MM-dd HH:mm:ss");
                    //var enddate = report.end_date.ToString("yyyy-MM-dd HH:mm:ss");
                    //var startDateTime = DateTime.ParseExact(Startdate, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                    //var endDateTime = DateTime.ParseExact(enddate, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

                    DataTable fileQCDT = new DataTable();
                    fileQCDT.Columns.Add("File Number");
                    fileQCDT.Columns.Add("Hblcount");
                    fileQCDT.Columns.Add("QcStatus");
                    fileQCDT.Columns.Add("Qcuser");
                    fileQCDT.Columns.Add("Eta");
                    fileQCDT.Columns.Add("FileCompletionDate");
                    fileQCDT.Columns.Add("FileCompletionDate(IST)");
                    fileQCDT.Columns.Add("Production Date");

                    DataTable hblQCDT = new DataTable();
                    hblQCDT.Columns.Add("QC Date");
                    hblQCDT.Columns.Add("QC Date(IST)");
                    hblQCDT.Columns.Add("Process Date");
                    hblQCDT.Columns.Add("Process Date(IST)");
                    hblQCDT.Columns.Add("EMP ID");
                    hblQCDT.Columns.Add("Name");
                    hblQCDT.Columns.Add("File Name");
                    hblQCDT.Columns.Add("HBL No");
                    hblQCDT.Columns.Add("QC Name");
                    hblQCDT.Columns.Add("FieldName");
                    hblQCDT.Columns.Add("L1");
                    hblQCDT.Columns.Add("L2");
                    hblQCDT.Columns.Add("L3");
                    hblQCDT.Columns.Add("L4");
                    hblQCDT.Columns.Add("Error Type");
                    hblQCDT.Columns.Add("QcStatus");
                    hblQCDT.Columns.Add("Comments");
                    hblQCDT.Columns.Add("Office");
                    hblQCDT.Columns.Add("POL");
                    hblQCDT.Columns.Add("POD");
                    hblQCDT.Columns.Add("ICName");
                    hblQCDT.Columns.Add("StartDate");
                    hblQCDT.Columns.Add("EndDate");
                    hblQCDT.Columns.Add("Production Date");



                    //do not change below code.If you want to change please discuss with Vaibhav Aher
                    var fileQCReult = _ctx.FileMaster
                         .Where(x => x.FileComplitionDate.Value.Date >= Startdate.Date && x.FileComplitionDate.Value.Date <= enddate.Date)
                         .Select(x => new ReportQCFileMasterModel
                         {
                             FileNumber = x.FileNumber.Trim(),
                             Hblcount = x.Hblcount,
                             QcStatus = x.QcStatus.Trim(),
                             Qcuser = _ctx.UserMaster.Where(y => y.Wnsid == x.Icuser).Select(y => y.Doc_Contact).FirstOrDefault(),
                             Eta = x.Eta == null ? null : x.Eta,
                             FileComplitionDate = x.FileComplitionDate,
                             FileCompletionDateIST = x.FileComplitionDate == null ? "" : TimeZoneInfo.ConvertTimeFromUtc((DateTime)x.FileComplitionDate, istTimeZone).ToString(),
                             ProductionDate = x.FileComplitionDate.HasValue ? x.FileComplitionDate.Value.ToShortDateString() : ""
                         })
                         .ToList();

                    var hblQCReport = _ctx.QcMaster
                        .Include(x => x.FileMaster)
                        .Where(x => x.StartTime.Value.Date >= Startdate.Date && x.StartTime.Value.Date <= enddate.Date)
                        .Select(x => new QCAuditReport
                        {
                            QCdate = x.StartTime,
                            QCDateIST = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone).ToString() : "",
                            //Processdate = x.FileMaster.FileComplitionDate,
                            //ProcessDateIST = x.FileMaster.FileComplitionDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileMaster.FileComplitionDate.Value, istTimeZone).ToString() : "",
                            EMP_ID = x.FileMaster.Hbluser.Trim(),
                            Name = _ctx.UserMaster.Where(y => y.Wnsid == x.FileMaster.Hbluser).Select(y => y.Doc_Contact).FirstOrDefault(),
                            FileName = x.FileMaster.FileNumber.Trim(),
                            HBLNo = x.HblNo.Trim(),
                            QCName = _ctx.UserMaster.Where(y => y.Wnsid == x.FileMaster.Icuser).Select(y => y.Doc_Contact).FirstOrDefault(),
                            FieldName = x.ErrorField.Trim(),
                            L1 = x.L1comment.Trim(),
                            L2 = x.L2comment.Trim(),
                            L3 = x.L3comment.Trim(),
                            L4 = x.L4comment.Trim(),
                            ErrorType = x.ErrorType.Trim(),
                            QcStatus = x.QcStatus.Trim(),
                            Comments = x.Comment.Trim(),
                            Office = x.FileMaster.Office.Trim(),
                            POL = x.FileMaster.Pol.Trim(),
                            POD = x.FileMaster.Pod.Trim(),
                            ICName = x.FileMaster.ContactPerson.Trim(),
                            StartTime = x.StartTime,
                            EndTime = x.EndTime,
                            ProducationDate = x.StartTime.HasValue ? x.StartTime.Value.ToShortDateString() : ""
                        }).ToList();


                    //result5 = result5.Where(x => x.FileComplitionDate >= startDateTime && x.FileComplitionDate <= endDateTime).ToList();
                    //result6 = result6.Where(x => x.StartTime >= startDateTime && x.StartTime <= endDateTime).ToList();
                    // DataTable dtt4 = ToDataTable(result4);
                    DataTable fileQCDTT = ToDataTable(fileQCReult);
                    DataTable hblQCDTT = ToDataTable(hblQCReport);

                    foreach (DataRow item in fileQCDTT.Rows)
                    {
                        DataRow dr = fileQCDT.NewRow();
                        for (int i = 0; i < fileQCDTT.Columns.Count; i++)
                        {
                            dr[i] = item[i];
                        }
                        fileQCDT.Rows.Add(dr);
                    }
                    foreach (DataRow item in hblQCDTT.Rows)
                    {
                        DataRow dr = hblQCDT.NewRow();
                        for (int i = 0; i < hblQCDTT.Columns.Count; i++)
                        {
                            dr[i] = item[i];
                        }
                        hblQCDT.Rows.Add(dr);
                    }
                    string filename = "";

                    //filename = saveFile.FileName;

                    string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        // dt4.TableName = "QcMaster Data";
                        fileQCDT.TableName = "QcFileMaster Data";
                        hblQCDT.TableName = "QCAudit Data";
                        //var wsQCData = wb.Worksheets.Add(dt4);
                        // wsQCData.Columns().AdjustToContents();
                        var fileQC = wb.Worksheets.Add(fileQCDT);
                        fileQC.Columns().AdjustToContents();
                        var fileQCAudit = wb.Worksheets.Add(hblQCDT);
                        fileQCAudit.Columns().AdjustToContents();

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"QCAuditReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }

                            // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                }
            }

            //do not change below code.If you want to change please discuss with Vaibhav Aher

            else
            {

                IQueryable<UserMaster> udata = _ctx.Set<UserMaster>().AsQueryable();
                if (report.start_date != null && report.end_date != null)
                {

                    var Startdate = report.start_date;
                    var enddate = report.end_date;
                    DataTable fileDT = new DataTable();
                    fileDT.Columns.Add("File Number");
                    fileDT.Columns.Add("Container No");
                    fileDT.Columns.Add("HBL Count");
                    fileDT.Columns.Add("POD");
                    fileDT.Columns.Add("POL");
                    fileDT.Columns.Add("ETA");
                    fileDT.Columns.Add("Office");
                    fileDT.Columns.Add("Priority");
                    fileDT.Columns.Add("Contact Person");
                    fileDT.Columns.Add("File Creation Date");
                    fileDT.Columns.Add("File Creation Date(IST)");
                    fileDT.Columns.Add("File Processing Date");
                    fileDT.Columns.Add("File Processing Date(IST)");
                    fileDT.Columns.Add("File Complition Date");
                    fileDT.Columns.Add("File Complition Date(IST)");
                    fileDT.Columns.Add("File createBy");
                    fileDT.Columns.Add("File CompletedBy");
                    fileDT.Columns.Add("File Complition Status");
                    fileDT.Columns.Add("Production Date");


                    DataTable hblDT = new DataTable();
                    hblDT.Columns.Add("File Number");
                    hblDT.Columns.Add("Container Number");
                    hblDT.Columns.Add("HBL No");
                    hblDT.Columns.Add("Hbl POD");
                    hblDT.Columns.Add("Hbl PLD");
                    hblDT.Columns.Add("Hbl Processing Status");
                    hblDT.Columns.Add("Hbl Processing Date");
                    hblDT.Columns.Add("Hbl Processing Date(IST)");
                    hblDT.Columns.Add("Hbl Processing Comment");
                    hblDT.Columns.Add("Invoicing Status");
                    hblDT.Columns.Add("Invoice Processing Date");
                    hblDT.Columns.Add("Invoice Processing Date(IST)");
                    hblDT.Columns.Add("Invoice Processing Comment");
                    hblDT.Columns.Add("AMS Status");
                    hblDT.Columns.Add("AMS Processing Date");
                    hblDT.Columns.Add("AMS Processing Date(IST)");
                    hblDT.Columns.Add("AMS Processing Comment");
                    hblDT.Columns.Add("HBL CompletedBy");
                    hblDT.Columns.Add("Production Date");
                    hblDT.Columns.Add("File Completion Date");
                    hblDT.Columns.Add("File Completion Date(IST)");

                    DataTable fileCreationDT = new DataTable();
                    fileCreationDT.Columns.Add("File Number");
                    fileCreationDT.Columns.Add("Container#");
                    fileCreationDT.Columns.Add("Received Date");
                    fileCreationDT.Columns.Add("Received Date(IST)");
                    fileCreationDT.Columns.Add("Created Date");
                    fileCreationDT.Columns.Add("Created Date(IST)");
                    fileCreationDT.Columns.Add("Created By");
                    fileCreationDT.Columns.Add("Production Date");


                    //do not change below code.If you want to change please discuss with Vaibhav Aher
                    var fileResult = _ctx.FileMaster
                        .Where(x => x.FileComplitionDate.Value.Date >= Startdate.Date && x.FileComplitionDate.Value.Date <= enddate.Date)
                        .Select(x => new ReportModel
                        {
                            FileNumber = x.FileNumber.Trim(),
                            Container = x.Container.Trim(),
                            hblcnt = x.Hblcount,
                            pod = x.Pod.Trim(),
                            pol = x.Pol.Trim(),
                            Eta = x.Eta,
                            office = x.Office.Trim(),
                            filetype = x.FileType.Trim(),
                            contactperson = x.ContactPerson.Trim(),
                            filecreationdate = x.CreateDateTime,
                            fileCreationDateIST = x.CreateDateTime == null ? "" : Convert.ToString(TimeZoneInfo.ConvertTimeFromUtc((DateTime)x.CreateDateTime, istTimeZone)),
                            fileProcessingDate = x.FileStartTime,
                            fileProcessingDateIST = x.FileStartTime == null ? "" : Convert.ToString(TimeZoneInfo.ConvertTimeFromUtc((DateTime)x.FileStartTime, istTimeZone)),
                            filecomplitiondate = x.FileComplitionDate,
                            fileCompletionDateIST = x.FileComplitionDate == null ? "" : Convert.ToString(TimeZoneInfo.ConvertTimeFromUtc((DateTime)x.FileComplitionDate, istTimeZone)),
                            createdby = udata.Where(y => y.Id == x.UserId).Select(y => y.Doc_Contact).FirstOrDefault(),
                            filecomuser = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.Doc_Contact).FirstOrDefault(),
                            filecomStatus = x.Hblstatus.Trim(),
                            productionDate = x.FileComplitionDate == null ? "" : Convert.ToDateTime(x.FileComplitionDate).ToShortDateString()
                        })
                        .ToList();


                    //do not change below code.If you want to change please discuss with Vaibhav Aher
                    var hblResult = _ctx.Hblmaster
                        .Join(
                            _ctx.FileMaster,
                            hbl => hbl.FileNumber,
                            file => file.FileNumber,
                            (hbl, file) => new { hbl, file }
                        ).Where(x => x.file.FileComplitionDate.Value.Date >= Startdate.Date && x.file.FileComplitionDate.Value.Date <= enddate.Date)
                        .Select(x => new HBLDetailModel
                        {
                            FileNumber = x.hbl.FileNumber.Trim(),
                            Container = x.file.Container.Trim(),
                            Hblno = x.hbl.Hblno.Trim(),
                            hblpod = x.hbl.Pod.Trim(),
                            hblpld = x.hbl.Pld.Trim(),
                            hblprostatus = x.hbl.HblprocessingStatus.Trim(),
                            hblprodate = x.hbl.HblprocessingDate,
                            hblprodateIST = x.hbl.HblprocessingDate.HasValue
                                ? TimeZoneInfo.ConvertTimeFromUtc(x.hbl.HblprocessingDate.Value, istTimeZone).ToString()
                                : "", // Use nullable DateTime
                            hblprocomment = x.hbl.Hblcomments.Trim(),
                            invoicestatus = x.hbl.InvoicingStatus.Trim(),
                            invoicedate = x.hbl.InvoicingDate != null
                                ? x.hbl.InvoicingDate.ToString()
                                : "", // Use nullable DateTime
                            invoiceDateIST = x.hbl.InvoicingDate != null
                                ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.hbl.InvoicingDate), istTimeZone).ToString()
                                : "", // Use nullable DateTime
                            invoiceprocomment = x.hbl.InvoicingComments.Trim(),
                            amsstatus = x.hbl.Amsstatus.Trim(),
                            amsdate = x.hbl.AmsprocessingDate,
                            amsDateIST = x.hbl.AmsprocessingDate.HasValue
                                ? TimeZoneInfo.ConvertTimeFromUtc(x.hbl.AmsprocessingDate.Value, istTimeZone).ToString()
                                : "", // Use nullable DateTime
                            HblCompletedBy = udata
                                .Where(y => y != null && y.Id == x.hbl.UserId)
                                .Select(y => y.Doc_Contact)
                                .FirstOrDefault() ?? "", // Use the null-coalescing operator
                            productionDate = x.hbl.HblprocessingDate.HasValue
                                ? x.hbl.HblprocessingDate.Value.ToShortDateString()
                                : "", // Use nullable DateTime
                            FileComplitionDate = x.file.FileComplitionDate,
                            FileComplitionDateIST = x.file.FileComplitionDate.HasValue
                                ? TimeZoneInfo.ConvertTimeFromUtc(x.file.FileComplitionDate.Value, istTimeZone).ToString()
                                : ""
                        }).ToList();


                    //var fileResult = _ctx.FileMaster
                    //    .Where(x => x.FileComplitionDate >= Startdate && x.FileComplitionDate <= enddate)
                    //    .Select(x => new ReportModel
                    //    {
                    //        FileNumber = x.FileNumber.Trim(),
                    //        Container = x.Container.Trim(),
                    //        hblcnt = x.Hblcount,
                    //        pod = x.Pod.Trim(),
                    //        pol = x.Pol.Trim(),
                    //        Eta = x.Eta,
                    //        office = x.Office.Trim(),
                    //        filetype = x.FileType.Trim(),
                    //        contactperson = x.ContactPerson.Trim(),
                    //        filecreationdate = x.CreateDateTime,
                    //        fileCreationDateIST = x.CreateDateTime == null ? "" : Convert.ToString(TimeZoneInfo.ConvertTimeFromUtc((DateTime)x.CreateDateTime, istTimeZone)),
                    //        fileProcessingDate = x.FileStartTime,
                    //        fileProcessingDateIST = x.FileStartTime == null ? "" : Convert.ToString(TimeZoneInfo.ConvertTimeFromUtc((DateTime)x.FileStartTime, istTimeZone)),
                    //        filecomplitiondate = x.FileComplitionDate,
                    //        fileCompletionDateIST = x.FileComplitionDate == null ? "" : Convert.ToString(TimeZoneInfo.ConvertTimeFromUtc((DateTime)x.FileComplitionDate, istTimeZone)),
                    //        createdby = udata.Where(y => y.Id == x.UserId).Select(y => y.Doc_Contact).FirstOrDefault(),
                    //        filecomuser = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.Doc_Contact).FirstOrDefault(),
                    //        filecomStatus = x.Hblstatus.Trim(),
                    //        productionDate = x.FileComplitionDate == null ? "" : Convert.ToDateTime(x.FileComplitionDate).ToShortDateString()
                    //    })
                    //    .ToList();

                    //var hblResult = _ctx.Hblmaster
                    //    .Join(
                    //        fileResult,
                    //        hbl => hbl.FileNumber,
                    //        file => file.FileNumber,
                    //        (hbl, file) => new { hbl, file }
                    //    ).Where(x => x.file.filecomplitiondate >= Startdate && x.file.filecomplitiondate <= enddate)
                    //    .Select(x => new HBLDetailModel
                    //    {
                    //        FileNumber = x.hbl.FileNumber.Trim(),
                    //        Container = x.file.Container.Trim(),
                    //        Hblno = x.hbl.Hblno.Trim(),
                    //        hblpod = x.hbl.Pod.Trim(),
                    //        hblpld = x.hbl.Pld.Trim(),
                    //        hblprostatus = x.hbl.HblprocessingStatus.Trim(),
                    //        hblprodate = x.hbl.HblprocessingDate,
                    //        hblprodateIST = x.hbl.HblprocessingDate.HasValue
                    //            ? TimeZoneInfo.ConvertTimeFromUtc(x.hbl.HblprocessingDate.Value, istTimeZone).ToString()
                    //            : "", // Use nullable DateTime
                    //        hblprocomment = x.hbl.Hblcomments.Trim(),
                    //        invoicestatus = x.hbl.InvoicingStatus.Trim(),
                    //        invoicedate = x.hbl.InvoicingDate != null
                    //            ? x.hbl.InvoicingDate.ToString()
                    //            : "", // Use nullable DateTime
                    //        invoiceDateIST = x.hbl.InvoicingDate != null
                    //            ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.hbl.InvoicingDate), istTimeZone).ToString()
                    //            : "", // Use nullable DateTime
                    //        invoiceprocomment = x.hbl.InvoicingComments.Trim(),
                    //        amsstatus = x.hbl.Amsstatus.Trim(),
                    //        amsdate = x.hbl.AmsprocessingDate,
                    //        amsDateIST = x.hbl.AmsprocessingDate.HasValue
                    //            ? TimeZoneInfo.ConvertTimeFromUtc(x.hbl.AmsprocessingDate.Value, istTimeZone).ToString()
                    //            : "", // Use nullable DateTime
                    //        HblCompletedBy = udata
                    //            .Where(y => y != null && y.Id == x.hbl.UserId)
                    //            .Select(y => y.Doc_Contact)
                    //            .FirstOrDefault() ?? "", // Use the null-coalescing operator
                    //        productionDate = x.hbl.HblprocessingDate.HasValue
                    //            ? x.hbl.HblprocessingDate.Value.ToShortDateString()
                    //            : "", // Use nullable DateTime
                    //        FileComplitionDate = x.file.fileProcessingDate,
                    //        FileComplitionDateIST = x.file.filecomplitiondate.HasValue
                    //            ? TimeZoneInfo.ConvertTimeFromUtc(x.file.filecomplitiondate.Value, istTimeZone).ToString()
                    //            : ""
                    //    })
                    //    .ToList();


                    var fileCreationResult = _ctx.FileMaster
                        .Where(x => x.CreateDateTime.Value.Date >= Startdate.Date && x.CreateDateTime.Value.Date <= enddate.Date)
                        .Select(x => new FileCreationReportModel
                        {
                            FileNumber = x.FileNumber.Trim(),
                            Container = x.Container.Trim(),
                            FileReceivedDate = x.RecievedDate,
                            FileReceivedDateIST = x.RecievedDate == null ? "" : TimeZoneInfo.ConvertTimeFromUtc((DateTime)x.RecievedDate, istTimeZone).ToString(),
                            filecreationdate = x.CreateDateTime,
                            fileCreationDateIST = x.CreateDateTime == null ? "" : TimeZoneInfo.ConvertTimeFromUtc((DateTime)x.CreateDateTime, istTimeZone).ToString(),
                            createdby = udata.Where(y => y.Id == x.UserId).Select(y => y.Doc_Contact).FirstOrDefault(),
                            ProductionDate = x.CreateDateTime == null ? "" : Convert.ToDateTime(x.CreateDateTime).ToShortDateString()
                        })
                        .ToList();

                    DataTable fileDTT = ToDataTable(fileResult);
                    DataTable hblDTT = ToDataTable(hblResult);
                    DataTable fileCreationDTT = ToDataTable(fileCreationResult);


                    foreach (DataRow item in fileDTT.Rows)
                    {
                        DataRow dr = fileDT.NewRow();
                        for (int i = 0; i < fileDTT.Columns.Count; i++)
                        {
                            dr[i] = item[i];
                        }
                        fileDT.Rows.Add(dr);
                    }

                    foreach (DataRow item in hblDTT.Rows)
                    {
                        DataRow dr = hblDT.NewRow();
                        for (int i = 0; i < hblDTT.Columns.Count; i++)
                        {
                            dr[i] = item[i];
                        }
                        hblDT.Rows.Add(dr);
                    }

                    foreach (DataRow item in fileCreationDTT.Rows)
                    {
                        DataRow dr = fileCreationDT.NewRow();
                        for (int i = 0; i < fileCreationDTT.Columns.Count; i++)
                        {
                            dr[i] = item[i];
                        }
                        fileCreationDT.Rows.Add(dr);
                    }


                    string filename = "";

                    //filename = saveFile.FileName;

                    string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        fileDT.TableName = "File Data";
                        hblDT.TableName = "HBL Data";
                        fileCreationDT.TableName = "File Creation Data";

                        var wsFileData = wb.Worksheets.Add(fileDT);
                        wsFileData.Columns().AdjustToContents();
                        var wsHblData = wb.Worksheets.Add(hblDT);
                        wsHblData.Columns().AdjustToContents();
                        var wsFileCreation = wb.Worksheets.Add(fileCreationDT);
                        wsFileCreation.Columns().AdjustToContents();

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"FileCreationReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }

                            // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    // System.Windows.Forms.MessageBox.Show("Please select date range", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            return View();
        }


        private static DateTime? ISTToUSAConvert(DateTime? cdate)
        {
            if (cdate.HasValue)
            {
                // Manually specify the UTC offset for Indian Standard Time
                TimeSpan istOffset = TimeSpan.FromHours(5.5); // UTC+05:30 for IST

                TimeZoneInfo estTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");

                // Convert IST time to UTC using the manual offset
                DateTime utcDateTime = cdate.Value - istOffset;
                //DateTime usaDateTime = TimeZoneInfo.ConvertTimeFromUtc(utcDateTime, estTimeZone);
                return utcDateTime;
            }
            return null;
        }


        //Pre-Alert Pending Report Download
        [HttpPost]
        public ActionResult Pre_AlertReport()
        {
            IQueryable<UserMaster> udata = _ctx.Set<UserMaster>().AsQueryable();
            DataTable dt = new DataTable();
            dt.Columns.Add("File Number");
            dt.Columns.Add("Container");
            dt.Columns.Add("Mbl");
            dt.Columns.Add("HBLcount");
            dt.Columns.Add("Pod");
            dt.Columns.Add("Pol");
            dt.Columns.Add("ReceivedDate");
            dt.Columns.Add("Eta");
            dt.Columns.Add("Status");
            dt.Columns.Add("Priority");
            dt.Columns.Add("Remark");
            dt.Columns.Add("ComplitionTime");
            dt.Columns.Add("UserId");
            dt.Columns.Add("CreateDate");

            var result = _ctx.PreAlertMaster.Where(x => x.Status == "Pending").Select(x => new Models.PreAlertMasterReport
            {
                FileNumber = x.FileNumber,
                Container = x.Container,
                Mbl = x.Mbl,
                Hblcount = x.Hblcount,
                Pod = x.Pod,
                Pol = x.Pol,
                RecievedDate = x.RecievedDate,
                Eta = x.Eta,
                Status = x.Status,
                Priority = x.Priority,
                Remarks = x.Remarks,
                ComplitionTime = x.ComplitionTime,
                UserId = x.UserId,
                CreatedDate = x.CreatedDate
            }).ToList();

            DataTable dtt = ToDataTable(result);

            foreach (DataRow item in dtt.Rows)
            {
                DataRow dr = dt.NewRow();
                for (int i = 0; i < dtt.Columns.Count; i++)
                {
                    dr[i] = item[i];

                }
                dt.Rows.Add(dr);
            }

            string filename = "";

            //filename = saveFile.FileName;

            string apath = filename + ".xlsx";
            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "PreAlert Data";
                var wsFileData = wb.Worksheets.Add(dt);

                try
                {
                    using (MemoryStream stream = new MemoryStream())
                    {
                        wb.SaveAs(stream);
                        string excelname = $"PreAlertReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                    }

                    // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            return View();
        }

        //Change File Status
        [HttpPost]
        public JsonResult PreAlertChangeStatus([FromBody] PreAlertMasterViewModel file)
        {
            string Msg = "";

            if (file != null)
            {
                var found = _ctx.PreAlertMaster.Where(x => x.Container == file.Container).FirstOrDefault();

                if (found != null)
                {
                    if (found.Status == "Completed" && file.Status == "Completed")
                    {
                        Msg = "Filestatus already completed.";

                        found.Status = "Data Entry";
                        _ctx.PreAlertMaster.Update(found);
                        _ctx.SaveChanges();
                    }
                    else
                    {
                        if (file.Status == "Completed")
                        {
                            found.Status = file.Status;
                            found.ComplitionTime = DateTime.Now;
                            found.Status = "Data Entry";
                        }
                        else
                        {
                            if (found.Status == "" || found.FuserId == null)
                            {
                                Msg = "File is not allocated";
                            }
                            else
                            {
                                found.Status = file.Status;
                                found.ComplitionTime = DateTime.Now;
                            }
                        }

                        if (Msg == "File is not allocated")
                        {
                        }
                        else
                        {
                            _ctx.PreAlertMaster.Update(found);
                            _ctx.SaveChanges();

                            Msg = "File status Update Sucessfully";
                        }

                    }

                }
            }
            return Json(Msg);
        }

        //List to Database convert
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            return dataTable;
        }
        //QC Dashboard
        public ActionResult QCDashboard()
        {
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsDelete == false && x.IsActive == true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();

            ViewData["Users"] = (from u in _ctx.UserMaster
                                 join ur in _ctx.UserRoles
                                 on u.Id equals ur.UserId
                                 join r in _ctx.Roles
                                 on ur.RoleId equals r.Id
                                 where (r.Name == "QC" && u.IsActive == true && u.IsDelete == false)
                                 select new UserMasterModel
                                 {
                                     Id = u.Id,
                                     UserName = u.UserName,
                                     CitrixId = u.CitrixId
                                 }).OrderBy(x => x.CitrixId).ToList();

            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();
            return View();
        }

        //Get Next QC 
        [HttpPost]
        public JsonResult GetQC()
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            IQueryable<FileMaster> data = _ctx.Set<FileMaster>().AsQueryable();
            // List<QcMaster> QCdata = _ctx.QcMaster.ToList();
            IQueryable<UserMaster> udata = _ctx.Set<UserMaster>().AsQueryable();
            DateTime sixMonths = DateTime.UtcNow.AddMonths(-6);
            int totalRecord = 0;
            int filterRecord = 0;

            string key = "";
            string value = "";
            totalRecord = data.Count();

            List<FileMaster> result = new List<FileMaster>();
            if (!string.IsNullOrEmpty(searchValue))
            {
                string searchstring = "";
                foreach (string search in searchValue.Split('|', StringSplitOptions.RemoveEmptyEntries).ToList())
                {
                    if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" || search == "Received" || search == "OnHold" || search == "eta10" || search == "eta12" ||
                        search == "eta18")
                    {
                        searchValue = search;
                    }
                    else
                    {
                        try
                        {
                            key = search.Split('_')[0];
                            value = search.Split('_')[1];
                        }
                        catch (Exception ex)
                        {

                        }
                        if (key == "FileNumber")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + "=" + '"' + value + '"' + " && ";
                        }
                        else if (key == "Eta")
                        {
                            if (value != "")
                                searchstring = searchstring + key + "=" + '"' + Convert.ToDateTime(value) + '"' + " && ";
                        }
                        else if (key == "Office")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + ".Contains" + '(' + '"' + value + '"' + ')' + " && ";
                        }
                        else if (key == "Container")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + ".Contains" + '(' + '"' + value + '"' + ')' + " && ";
                        }
                        else if (key == "QcStatus")
                        {
                            if (value == "--select--" || value == "--Select--")
                            { }
                            else
                            {
                                searchstring = searchstring + key + "=" + '"' + value + '"' + " && ";
                            }
                        }
                        else if (key == "Pod")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + "=" + '"' + value.ToUpper() + '"' + " && ";
                        }
                        else if (key == "Icuser")
                        {
                            if (value == "--select--" || value == "--Select--")
                            { }
                            else
                            {
                                var find = udata.Where(x => x.UserName == value).Select(x => x.Wnsid).FirstOrDefault();
                                searchstring = searchstring + key + "=" + '"' + find + '"' + " && ";
                            }
                        }
                    }
                }
                if (searchstring != "")
                {
                    searchstring = searchstring.Substring(0, searchstring.Length - 3);
                    data = data.Where(searchstring.Trim());
                }
            }


            if (searchValue == "Completed" || searchValue == "WIP" || searchValue == "Pending" || searchValue == "eta10" || searchValue == "eta12"
                || searchValue == "eta18" || searchValue == "OnHold" || searchValue == "Received")
            {
                if (searchValue == "eta10")
                {
                    result = data.Where(x => x.Eta.HasValue && x.Eta.Value.Date <= DateTime.Now.Date && x.Eta.Value.Date >= DateTime.Now.AddDays(-10).Date && x.QcStatus == "Send to Qc").Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster,

                    }).ToList();
                }
                else if (searchValue == "eta12")
                {
                    result = data.Where(x => x.Eta != null && x.Eta.Value.Date > DateTime.Now.AddDays(-13).Date && x.Eta.Value.Date <= DateTime.Now.AddDays(-10).Date && x.QcStatus == "Send to Qc").Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster

                    }).ToList();
                }
                else if (searchValue == "eta18")
                {
                    result = data.Where(x => x.Eta != null && x.Eta.Value.Date > DateTime.Now.AddDays(-18).Date && x.Eta.Value.Date <= DateTime.Now.AddDays(-12).Date && x.QcStatus == "Send to Qc").Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster

                    }).ToList();
                }

                else if (searchValue == "OnHold")
                {
                    result = data.Where(x => (x.QcStatus == "OnHold")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster

                    }).ToList();
                }
                else if (searchValue == "Received")
                {
                    result = data.Where(x => (x.QcStatus == "Pending" || x.QcStatus == "WIP" || x.QcStatus == "OnHold" || x.QcStatus == "Completed" || x.QcStatus == "Send to Qc" || x.QcStatus == "NotProcessed" || x.QcStatus == "NotInScope")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster

                    }).ToList();
                }

                else if (searchValue == "Pending")
                {
                    result = data.Where(x => (x.QcStatus == "Pending" || x.QcStatus == "Send to Qc")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster

                    }).ToList();
                }
                else if (searchValue == "Completed")
                {
                    result = data.Where(x => (x.QcStatus == "Completed" || x.QcStatus == "NotProcessed")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster
                        //Hblmaster = x.Hblmaster
                    }).ToList();
                }
                else
                {

                    result = data.Where(x => x.QcStatus == searchValue).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster,

                    }).ToList();
                }
            }
            else
            {

                result = data.Include(x => x.QcMaster).Select(x => new FileMaster
                {
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                    Hblstatus = x.Hblstatus,
                    FileComplitionDate = x.FileComplitionDate,
                    Hblcount = x.Hblcount,
                    Pod = x.Pod,
                    Eta = x.Eta,
                    QcStatus = x.QcStatus,
                    Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                    QcMaster = x.QcMaster
                    //Hblmaster = x.Hblmaster
                }).Where(x => (x.QcStatus == "Pending" || x.QcStatus == "WIP" || x.QcStatus == "OnHold" || x.QcStatus == "Completed" || x.QcStatus == "Send to Qc" || x.QcStatus == "NotProcessed" || x.QcStatus == "NotInScope")).ToList();


            }

            DateTime endtime = DateTime.Now;
            stopwatch.Stop();

            IQueryable<FileMaster> SortedData = result.Where(x => x.FileComplitionDate.Value.Date >= sixMonths.Date || x.FileComplitionDate == (DateTime?)null).AsQueryable();

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            }
            catch { }

            filterRecord = SortedData.Count();//data
            //SortedData = SortedData.Where(x => x.RecievedDate.Value.Date >= threeMonths.Date);//data
            totalRecord = data.Count();//data6
            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = filterRecord,
                data = SortedData.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).ToList()  //result//data6
            };
            //filterRecord=data.Count();
            //var returnObj = new
            //{
            //    draw = draw,
            //    recordsTotal = totalRecord,
            //    recordsFiltered = filterRecord,
            //    data = result
            //};

            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            TimeSpan elapsedTime = stopwatch.Elapsed;
            return Json(returnObj);
        }
        //Get QCDashboard count
        public JsonResult GetQCDashboardCount()
        {
            DateTime sixMonths = DateTime.UtcNow.AddMonths(-6);
            //var file = _ctx.FileMaster.Where(x => x.RecievedDate.Value.Date >= threeMonths.Date).ToList();
            var file = _ctx.FileMaster.Where(x => x.FileComplitionDate.Value.Date >= sixMonths.Date || x.FileComplitionDate == (DateTime?)null).ToList();
            var Received_count = file.Where(x => (x.QcStatus == "Pending" || x.QcStatus == "WIP" || x.QcStatus == "OnHold" || x.QcStatus == "Completed" || x.QcStatus == "Send to Qc" || x.QcStatus == "NotProcessed" || x.QcStatus == "NotInScope")).ToList();
            var Pending_count = file.Where(x => (x.QcStatus == "Pending" || x.QcStatus == "Send to Qc")).ToList();
            var WIP_count = file.Where(x => x.QcStatus == "WIP").ToList();
            var OnHold_count = file.Where(x => x.QcStatus == "OnHold").ToList();
            var Completed_count = file.Where(x => x.QcStatus == "Completed" || x.QcStatus == "NotProcessed" || x.QcStatus == "NotInScope").ToList();
            //var Eta10_count = file.Where(x => x.Eta != null && x.Eta.Value.Date >= DateTime.Now.AddDays(-10).Date && x.Eta.Value.Date <= DateTime.Now.Date && x.QcStatus == "Send to Qc").Count();
            //var Eta12_count = file.Where(x => x.Eta != null && x.Eta.Value.Date > DateTime.Now.AddDays(-10).Date && x.Eta.Value.Date <= DateTime.Now.AddDays(-12) && x.QcStatus == "Send to Qc").Count();
            //var eta18 = file.Where(x => x.Eta != null && x.Eta.Value.Date > DateTime.Now.AddDays(-12) && x.Eta.Value.Date <= DateTime.Now.AddDays(-18) && x.QcStatus == "Send to Qc").Count();
            var Eta10_count = file.Where(x => x.Eta.HasValue && x.Eta.Value.Date <= DateTime.Now.Date && x.Eta.Value.Date >= DateTime.Now.AddDays(-10).Date && x.QcStatus == "Send to Qc").Count();
            var Eta12_count = file.Where(x => x.Eta != null && x.Eta.Value.Date > DateTime.Now.AddDays(-13).Date && x.Eta.Value.Date <= DateTime.Now.AddDays(-10).Date && x.QcStatus == "Send to Qc").Count();
            var eta18 = file.Where(x => x.Eta != null && x.Eta.Value.Date > DateTime.Now.AddDays(-18).Date && x.Eta.Value.Date <= DateTime.Now.AddDays(-12).Date && x.QcStatus == "Send to Qc").Count();


            QcDashboardCount qc = new QcDashboardCount
            {
                Received = Received_count.Count,
                Pending = Pending_count.Count,
                WIP = WIP_count.Count,
                OnHold = OnHold_count.Count,
                Completed = Completed_count.Count,
                ETA10 = Eta10_count,
                ETA12 = Eta12_count
            };

            return Json(qc);
        }
        //QC File Allocation
        [HttpPost]
        public JsonResult QCFileAllocate([FromBody] FileMasterViewModel model)
        {
            string Msg = "";
            try
            {
                var userid = _ctx.Users.Where(x => x.Id == model.QcUser).Select(x => x.Wnsid).FirstOrDefault();
                var fileno = _ctx.FileMaster.Where(x => x.FileNumber == model.FileNumber).FirstOrDefault();

                if (fileno != null)
                {
                    fileno.QcStatus = "WIP";
                    fileno.Icuser = userid;
                    _ctx.FileMaster.Update(fileno);
                    Msg = "File Allocation sucessfully";
                }
                _ctx.SaveChanges();
            }
            catch (Exception ex)
            {

            }
            return Json(Msg);
        }
        //QC fileDeallocation
        public IActionResult QCfileDeAllocate(string Filenumber)
        {
            try
            {
                var fileno = _ctx.FileMaster.Where(x => x.FileNumber == Filenumber).FirstOrDefault();
                if (fileno != null)
                {
                    //fileno.QcStatus = "Send to Qc";
                    fileno.Icuser = "";
                }
                _ctx.FileMaster.Update(fileno);
                _ctx.SaveChanges();
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("QcDashboard", "Admin");
        }
        //QC Change Status
        [HttpPost]
        public JsonResult QCChangeStatus([FromBody] FileMasterViewModel file)
        {
            string Msg = "";
            try
            {
                if (file != null)
                {
                    var userid = _ctx.Users.Where(x => x.Id == file.QcUser).Select(x => x.Wnsid).FirstOrDefault();
                    var found = _ctx.FileMaster.Include(x => x.QcMaster).Where(x => x.FileNumber == file.FileNumber).FirstOrDefault();

                    if (found != null)
                    {
                        if (found.Hblstatus == "Completed")
                        {
                            if (found.QcStatus == "Completed" && file.QcStatus == "Completed")
                            {
                                Msg = "Filestatus already completed.";
                            }
                            else
                            {
                                found.QcStatus = file.QcStatus;
                                found.Icuser = userid;
                                _ctx.FileMaster.Update(found);
                                _ctx.SaveChanges();

                                var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                                List<Hblmaster> hbls = _ctx.Hblmaster.Where(x => x.FileNumber == file.FileNumber).ToList();
                                foreach (Hblmaster hbl in hbls)
                                {
                                    QcMaster qc = _ctx.QcMaster.Where(x => x.HblNo == hbl.Hblno).FirstOrDefault();
                                    if (qc == null)
                                    {
                                        qc = new QcMaster()
                                        {
                                            FileNumber = file.FileNumber,
                                            HblNo = hbl.Hblno,
                                            ErrorField = "No Error",
                                            ErrorType = "No Error",
                                            Comment = "No Error by Admin " + username,
                                            QcStatus = file.QcStatus,
                                            Qcuser = userid,
                                            StartTime = DateTime.Now,
                                            EndTime = DateTime.Now
                                        };
                                        _ctx.QcMaster.Add(qc);
                                        _ctx.SaveChanges();
                                    }
                                }
                                Msg = "Filestatus Update Sucessfully";
                            }
                        }
                        else
                        {
                            Msg = "We can't changes status file status is not completed.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Msg = ex.Message;
            }            
            return Json(Msg);
        }
        //Get QC Data
        [HttpPost]
        public JsonResult GetQcdata([FromBody] FileMasterViewModel file)
        {
            var result = _ctx.QcHblWiseData.Where(x => x.FileNumber == file.FileNumber).Select(x => x).ToList();
            return Json(result);
        }

        //Get UserCount
        public ActionResult GetCountofUser()
        {
            return View();
        }

        [HttpPost]
        public JsonResult GetUserDatacount()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            List<UserMaster> udata = _ctx.UserMaster.Where(x => x.IsDelete == false && x.IsActive == true).OrderBy(x => x.CitrixId).ToList();
            List<FileMaster> fdata = _ctx.FileMaster.ToList();
            var result = from c in fdata
                         group c.Hbluser by c.Hbluser into g
                         select new
                         {
                             Username = udata.Where(x => x.Wnsid == g.Key).Select(x => x.Doc_Contact).FirstOrDefault(),
                             Total = fdata.Where(x => x.Hbluser == g.Key).Count(),
                             WIP = fdata.Where(x => x.Hbluser == g.Key && x.Hblstatus == "WIP").Count(),
                             Pending = fdata.Where(x => x.Hbluser == g.Key && (x.Hblstatus == "Pending")).Count(),
                             Completed = fdata.Where(x => x.Hbluser == g.Key && x.Hblstatus == "Completed").Count()
                         };

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    result = result.AsQueryable().OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result.Where(x => x.Username != null)
            };

            return Json(returnObj);
        }

        [HttpPost]
        public JsonResult GetQCUserDatacount()
        {

            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            List<UserMaster> udata = _ctx.UserMaster.Where(x => x.IsDelete == false && x.IsActive == true).OrderBy(x => x.CitrixId).ToList();
            List<FileMaster> fdata = _ctx.FileMaster.ToList();
            var result = from c in fdata
                         group c.Icuser by c.Icuser into g
                         select new
                         {
                             Username = udata.Where(x => x.Wnsid == g.Key).Select(x => x.Doc_Contact).FirstOrDefault(),
                             Total = fdata.Where(x => x.Icuser == g.Key).Count(),
                             WIP = fdata.Where(x => x.Icuser == g.Key && x.QcStatus == "WIP").Count(),
                             Pending = fdata.Where(x => x.Icuser == g.Key && (x.QcStatus == "Pending" || x.QcStatus == "Send to Qc" || x.QcStatus == "NotProcessed" || x.QcStatus == "NotInScope")).Count(),
                             Completed = fdata.Where(x => x.Icuser == g.Key && x.QcStatus == "Completed").Count()
                         };
            try
            {
                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    result = result.AsQueryable().OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result.Where(x => x.Username != null && x.Total != 0)
            };

            return Json(returnObj);
        }

        //Report File Downloaded from Dashboard
        [HttpPost]
        public IActionResult FilterDataReport([FromBody] FilterDataModel model)
        {
            // Access the properties of the received JSON object
            IQueryable<FileMaster> data = _ctx.Set<FileMaster>().AsQueryable();
            IQueryable<UserMaster> udata = _ctx.Set<UserMaster>().AsQueryable();
            //IQueryable<QcMaster> qcdata = _ctx.Set<QcMaster>().AsQueryable();
            IQueryable<OfficeMaster> odata = _ctx.Set<OfficeMaster>().AsQueryable();

            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            int totalRecord = 0;
            int filterRecord = 0;
            //var draw = Request.Form["draw"].FirstOrDefault();
            totalRecord = data.Count();
            string key = "";
            string value = "";
            Boolean searchflag = false;
            Boolean sortflag = false;
            DateTime sixMonths = DateTime.UtcNow.AddMonths(-6);
            IQueryable<FileMasterViewModel> result = Enumerable.Empty<FileMasterViewModel>().AsQueryable();
            result = data.Select(x => new FileMasterViewModel
            {
                FileNumber = x.FileNumber,
                Container = x.Container,
                RecievedDate = x.RecievedDate,
                UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                Hblstatus = x.Hblstatus,
                FileComplitionDate = x.FileComplitionDate,
                Hblcount = x.Hblcount,
                Eta = x.Eta,
                EtaChangedBy = udata.Where(y => y.Wnsid == x.EtaChangedBy).Select(y => y.UserName).First(),
                Office = odata.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                CreateDateTime = x.CreateDateTime,
                PreviousEta = x.PreviousEta,
                EtaChangedDatetime = x.EtaChangedDatetime,
                EtaChangedComment = x.EtaChangedComment,
                QcStatus = x.QcStatus,
                FileType = x.FileType,
                Pol = x.Pol,
                Pod = x.Pod,
                MasterBl = x.MasterBl,
                SSL = x.SSL
            }).AsQueryable();

            IQueryable<FileMasterViewModel> SortedData = result.Where(x => x.FileComplitionDate.Value.Date >= sixMonths.Date || x.FileComplitionDate.Value.Date == (DateTime?)null).AsQueryable();

            if (!string.IsNullOrEmpty(model.fileNo))
            {
                SortedData = SortedData.Where(x => x.FileNumber == model.fileNo);
            }

            if (!string.IsNullOrEmpty(model.container))
            {
                SortedData = SortedData.Where(x => x.Container == model.container);
            }

            if (!string.IsNullOrEmpty(model.hblstatus) && model.hblstatus != "--select--")
            {
                SortedData = SortedData.Where(x => x.Hblstatus == model.hblstatus);
            }

            if (!string.IsNullOrEmpty(model.userId) && model.userId != "--select--")
            {
                var userName = _ctx.UserMaster.Where(x => x.Id == model.userId).Select(x => x.UserName).FirstOrDefault();
                if (userName != null)
                {
                    SortedData = SortedData.Where(x => x.UserId == userName);
                }
            }

            if (!string.IsNullOrEmpty(model.office) && model.office != "--select--")
            {
                SortedData = SortedData.Where(x => x.Office == model.office);
            }

            if (!string.IsNullOrEmpty(model.eta_d) && DateTime.TryParse(model.eta_d, out var etaDate))
            {
                SortedData = SortedData.Where(x => x.Eta.HasValue && x.Eta.Value.Date == etaDate.Date);
            }

            if (!string.IsNullOrEmpty(model.currentStatus))
            {
                switch (model.currentStatus)
                {
                    case "WIP":
                        SortedData = SortedData.Where(x => x.Hblstatus == model.currentStatus);
                        break;
                    case "Completed":
                        SortedData = SortedData.Where(x => x.Hblstatus == model.currentStatus);
                        break;
                    case "Pending":
                        SortedData = SortedData.Where(x => x.Hblstatus == model.currentStatus);
                        break;
                    case "Query":
                        SortedData = SortedData.Where(x => x.Hblstatus == model.currentStatus);
                        break;
                    case "UnAllocated":
                        SortedData = SortedData.Where(x => x.Hblstatus == "" || x.Hblstatus == null);
                        break;
                    case "eta10":
                        SortedData = SortedData.Where(x => x.Eta.HasValue && x.Eta.Value.Date <= DateTime.Now.Date.AddDays(10) && x.Hblstatus != "Completed");
                        break;
                    case "eta12":
                        SortedData = SortedData.Where(x => x.Eta.HasValue && x.Eta.Value.Date > DateTime.Now.Date.AddDays(10) && x.Eta.Value.Date <= DateTime.Now.Date.AddDays(12) && x.Hblstatus != "Completed");
                        break;
                    case "eta18":
                        SortedData = SortedData.Where(x => x.Eta.HasValue && x.Eta.Value.Date > DateTime.Now.Date.AddDays(12) && x.Eta.Value.Date <= DateTime.Now.Date.AddDays(18) && x.Hblstatus != "Completed");
                        break;
                }
            }

            //pageSize = SortedData.Count();

            
            var dashboard = SortedData.ToList();
            DataTable dt = ToDataTable(dashboard.ToList());
            string excelname = $"UserReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
            MemoryStream stream = new MemoryStream();
            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "File Data";
                var wsFileData = wb.Worksheets.Add(dt);
                wsFileData.Columns().AdjustToContents();
                try
                {
                    wb.SaveAs(stream);
                }
                catch (Exception ex)
                {

                }
            }
            // Return a response, if needed
            return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
        }

        [HttpPost]
        public IActionResult QCFilterDataReport([FromBody] QCDashboardReport model)
        {
            // Access the properties of the received JSON object

            //DataTable dt = ToDataTable(model.ToList());
            
            IQueryable<FileMaster> data = _ctx.Set<FileMaster>().AsQueryable();
            // List<QcMaster> QCdata = _ctx.QcMaster.ToList();
            IQueryable<UserMaster> udata = _ctx.Set<UserMaster>().AsQueryable();
            DateTime sixMonths = DateTime.UtcNow.AddMonths(-6);
            int totalRecord = 0;
            int filterRecord = 0;   
            var search = model.currentStatus;
            var searchValue = "";
            string key = "";
            string value = "";
            totalRecord = data.Count();

            List<FileMaster> result = new List<FileMaster>();
            if (!string.IsNullOrEmpty(model.currentStatus))
            {

                if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" || search == "Received" || search == "OnHold" || search == "eta10" || search == "eta12" ||
                    search == "eta18")
                {
                    searchValue = search;
                }

                if (model.FileNumber != "--select--" && model.FileNumber != "" && model.FileNumber  != null)
                {
                        data = data.Where(x => x.FileNumber == model.FileNumber);
                }
                else if (model.Eta != null)
                {
                    data = data.Where(x => x.Eta.Value.Date == model.Eta.Value.Date);
                }
                else if (model.QcStatus != "" && model.QcStatus != null && model.QcStatus != "--Select--" && model.QcStatus != "--select--")
                {
                    
                        data = data.Where(x => x.QcStatus == model.QcStatus);
                    
                }
                else if (model.Pod != "" && model.Pod != null && model.Pod != "--select--" && model.Pod != "--Select--")
                {
                    data = data.Where(x => x.Pod == model.Pod);
                }
                else if (model.Icuser != "" && model.Icuser != null && model.Icuser != "--select--" && model.Icuser != "--Select--")
                {
                    
                        var find = udata.Where(x => x.UserName == model.Icuser).Select(x => x.Wnsid).FirstOrDefault();
                        data = data.Where(x => x.Icuser == find);
                    
                }
            }


            if (searchValue == "Completed" || searchValue == "WIP" || searchValue == "Pending" || searchValue == "eta10" || searchValue == "eta12"
                || searchValue == "eta18" || searchValue == "OnHold" || searchValue == "Received")
            {
                if (searchValue == "eta10")
                {
                    result = data.Where(x => x.Eta.HasValue && x.Eta.Value.Date <= DateTime.Now.Date && x.Eta.Value.Date >= DateTime.Now.AddDays(-10).Date && x.QcStatus == "Send to Qc").Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster,

                    }).ToList();
                }
                else if (searchValue == "eta12")
                {
                    result = data.Where(x => x.Eta != null && x.Eta.Value.Date > DateTime.Now.AddDays(-13).Date && x.Eta.Value.Date <= DateTime.Now.AddDays(-10).Date && x.QcStatus == "Send to Qc").Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster

                    }).ToList();
                }
                else if (searchValue == "eta18")
                {
                    result = data.Where(x => x.Eta != null && x.Eta.Value.Date > DateTime.Now.AddDays(-18).Date && x.Eta.Value.Date <= DateTime.Now.AddDays(-12).Date && x.QcStatus == "Send to Qc").Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster

                    }).ToList();
                }

                else if (searchValue == "OnHold")
                {
                    result = data.Where(x => (x.QcStatus == "OnHold")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster

                    }).ToList();
                }
                else if (searchValue == "Received")
                {
                    result = data.Where(x => (x.QcStatus == "Pending" || x.QcStatus == "WIP" || x.QcStatus == "OnHold" || x.QcStatus == "Completed" || x.QcStatus == "Send to Qc" || x.QcStatus == "NotProcessed" || x.QcStatus == "NotInScope")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster

                    }).ToList();
                }

                else if (searchValue == "Pending")
                {
                    result = data.Where(x => (x.QcStatus == "Pending" || x.QcStatus == "Send to Qc")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster

                    }).ToList();
                }
                else if (searchValue == "Completed")
                {
                    result = data.Where(x => (x.QcStatus == "Completed" || x.QcStatus == "NotProcessed")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster
                        //Hblmaster = x.Hblmaster
                    }).ToList();
                }
                else
                {

                    result = data.Where(x => x.QcStatus == searchValue).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        FileComplitionDate = x.FileComplitionDate,
                        Hblcount = x.Hblcount,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        QcStatus = x.QcStatus,
                        Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster,

                    }).ToList();
                }
            }
            else
            {

                result = data.Include(x => x.QcMaster).Select(x => new FileMaster
                {
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                    Hblstatus = x.Hblstatus,
                    FileComplitionDate = x.FileComplitionDate,
                    Hblcount = x.Hblcount,
                    Pod = x.Pod,
                    Eta = x.Eta,
                    QcStatus = x.QcStatus,
                    Icuser = udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.UserName).First(),
                    QcMaster = x.QcMaster
                    //Hblmaster = x.Hblmaster
                }).Where(x => (x.QcStatus == "Pending" || x.QcStatus == "WIP" || x.QcStatus == "OnHold" || x.QcStatus == "Completed" || x.QcStatus == "Send to Qc" || x.QcStatus == "NotProcessed" || x.QcStatus == "NotInScope")).ToList();


            }

            DateTime endtime = DateTime.Now;

            IQueryable<FileMaster> SortedData = result
                .Where(x => (x.FileComplitionDate.HasValue && x.FileComplitionDate.Value.Date >= sixMonths.Date) || !x.FileComplitionDate.HasValue)
                .AsQueryable();

            DataTable dt = ToDataTable(SortedData.ToList());
            string excelname = $"UserReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
            MemoryStream stream = new MemoryStream();
            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "QC Data";
                var wsFileData = wb.Worksheets.Add(dt);
                try
                {
                    wb.SaveAs(stream);
                }
                catch (Exception ex)
                {

                }
            }
            // Return a response, if needed
            return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
        }

        [HttpPost]
        public IActionResult PreAleartFilterDataReport([FromBody] PreAlertReportFilter model)
        {
            // Access the properties of the received JSON object

            IQueryable<PreAlertMaster> data = _ctx.Set<PreAlertMaster>().AsQueryable();
            int totalRecord = 0;
            int filterRecord = 0;
            //DateTime threeMonth = DateTime.UtcNow.AddMonths(-6);
            totalRecord = data.Count();
            string searchValue = "";

            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();

            if (!string.IsNullOrEmpty(model.currentStatus))
            {

                if (model.currentStatus == "UnAllocated" || model.currentStatus == "Data Entry" || model.currentStatus == "Pending" || model.currentStatus == "Received" || model.currentStatus == "Missing")
                {
                    searchValue = model.currentStatus;
                }
            }
            if (model.Container != "" && model.Container != null)
            {
                data = data.Where(x => x.Container == model.Container).AsQueryable();
            }
            if (model.Eta != null && model.Eta != (DateTime?)null)
            {
                data = data.Where(x => x.Eta.Value.Date == model.Eta.Value.Date).AsQueryable();
            }
            if (model.Status != "" && model.Status != null && model.Status != "--select--" && model.Status != "--Select--")
            {
                data = data.Where(x => x.Status == model.Status).AsQueryable();
            }
            if (model.Office != "" && model.Office != null && model.Office != "--select--" && model.Office != "--Select--")
            {
                data = data.Where(x => x.Office == model.Office).AsQueryable();
            }

            List<PreAlertMasterViewModel> result = new List<PreAlertMasterViewModel>();

            if (searchValue == "Data Entry" || searchValue == "UnAllocated" || searchValue == "Missing" || searchValue == "Pending" || searchValue == "Received")
            {
                if (searchValue == "eta10")
                {
                    result = data.Where(x => x.Eta.Value.AddDays(-10) <= DateTime.Now && (x.Status == null || x.Status == "")).Select(x => new PreAlertMasterViewModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Wnsid == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Status = x.Status,
                        Mbl = x.Mbl,
                        ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        Priority = x.Priority,
                        Remarks = x.Remarks,
                        FuserId = _ctx.Users.Where(y => y.Id == x.FuserId).Select(y => y.UserName).FirstOrDefault(),
                    }).ToList();
                }
                else if (searchValue == "UnAllocated")
                {
                    result = data.Where(x => x.Status == null || x.Status == "").Select(x => new PreAlertMasterViewModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Status = x.Status,
                        Mbl = x.Mbl,
                        ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        Priority = x.Priority,
                        Remarks = x.Remarks,
                        FuserId = _ctx.Users.Where(y => y.Id == x.FuserId).Select(y => y.UserName).FirstOrDefault(),
                    }).ToList();

                }
                else if (searchValue == "Received")
                {
                    result = data.Select(x => new PreAlertMasterViewModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Status = x.Status,
                        Mbl = x.Mbl,
                        ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        Priority = x.Priority,
                        Remarks = x.Remarks,
                        FuserId = _ctx.Users.Where(y => y.Id == x.FuserId).Select(y => y.UserName).FirstOrDefault(),
                    }).ToList();

                }
                else
                {
                    result = data.Where(x => x.Status == searchValue).Select(x => new PreAlertMasterViewModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Status = x.Status,
                        Mbl = x.Mbl,
                        ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        Priority = x.Priority,
                        Remarks = x.Remarks,
                        FuserId = _ctx.Users.Where(y => y.Id == x.FuserId).Select(y => y.UserName).FirstOrDefault(),
                    }).ToList();
                }
            }
            else
            {
                result = data.Select(x => new PreAlertMasterViewModel
                {
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    RecievedDate = x.RecievedDate,
                    UserId = _ctx.Users.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                    Status = x.Status,
                    Mbl = x.Mbl,
                    ComplitionTime = x.ComplitionTime,
                    Hblcount = x.Hblcount,
                    Pol = x.Pol,
                    Pod = x.Pod,
                    Eta = x.Eta,
                    Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                    Priority = x.Priority,
                    Remarks = x.Remarks,
                    FuserId = _ctx.Users.Where(y => y.Id == x.FuserId).Select(y => y.UserName).FirstOrDefault(),
                }).ToList();
            }

            DataTable dt = ToDataTable(result);
            string excelname = $"UserReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
            MemoryStream stream = new MemoryStream();
            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "PreAlert Data";

                var wsFileData = wb.Worksheets.Add(dt);
                wsFileData.Columns().AdjustToContents();
                try
                {
                    wb.SaveAs(stream);
                }
                catch (Exception ex)
                {

                }
            }
            // Return a response, if needed
            return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
        }

        [HttpPost]
        public JsonResult GetUserDatacount1(string start_date, string end_date)
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

            List<UserMaster> udata = _ctx.UserMaster.Where(x => x.IsDelete == false && x.IsActive == true).OrderBy(x => x.CitrixId).ToList();
            List<FileMaster> fdata = _ctx.FileMaster.Where(x => x.FileComplitionDate >= Convert.ToDateTime(start_date) && x.FileComplitionDate <= Convert.ToDateTime(end_date)).ToList();
            var result = from c in fdata
                         group c.Hbluser by c.Hbluser into g
                         select new
                         {
                             Username = udata.Where(x => x.Wnsid == g.Key).Select(x => x.Doc_Contact).FirstOrDefault(),
                             Total = fdata.Where(x => x.Hbluser == g.Key).Count(),
                             WIP = fdata.Where(x => x.Hbluser == g.Key && x.Hblstatus == "WIP").Count(),
                             Pending = fdata.Where(x => x.Hbluser == g.Key && (x.Hblstatus == "Pending")).Count(),
                             Completed = fdata.Where(x => x.Hbluser == g.Key && x.Hblstatus == "Completed").Count()
                         };

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    result = result.AsQueryable().OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result.Where(x => x.Username != null)
            };

            return Json(returnObj);
        }

        [HttpPost]
        public JsonResult GetQCUserDatacount1(string start_date, string end_date)
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();


            List<UserMaster> udata = _ctx.UserMaster.ToList();
            List<QcMaster> fdata = _ctx.QcMaster.Where(x => x.StartTime >= Convert.ToDateTime(start_date) && x.EndTime <= Convert.ToDateTime(end_date)).ToList();


            var result = from c in fdata
                         group c.Qcuser by c.Qcuser into g
                         select new
                         {
                             Username = udata.Where(x => x.Wnsid == g.Key).Select(x => x.Doc_Contact).FirstOrDefault(),
                             Total = fdata.Where(x => x.Qcuser == g.Key).Count(),
                             WIP = fdata.Where(x => x.Qcuser == g.Key && x.QcStatus == "WIP").Count(),
                             Pending = fdata.Where(x => x.Qcuser == g.Key && (x.QcStatus == "Pending" || x.QcStatus == "Send to Qc" || x.QcStatus == "NotProcessed" || x.QcStatus == "NotInScope")).Count(),
                             Completed = fdata.Where(x => x.Qcuser == g.Key && x.QcStatus == "Completed").Count()
                         };

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    result = result.AsQueryable().OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result.Where(x => x.Username != null && x.Total != 0)
            };

            return Json(returnObj);
        }

        // Get Userlist Data
        [HttpPost]
        public JsonResult GetUserList()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

            List<RegViewModel> result = new List<RegViewModel>();
            result = (from u in _ctx.Users
                      join res in _ctx.UserRoles
                      on u.Id equals res.UserId
                      where u.IsActive == true && u.IsDelete == false
                      select new RegViewModel
                      {
                          UserName = u.UserName,
                          CitrixId = u.CitrixId,
                          Wnsid = u.Wnsid,
                          Userrole = _ctx.Roles.Where(x => x.Id == res.RoleId).Select(x => x.Name).FirstOrDefault(),
                          Primary_Location = _ctx.OfficeMaster.Where(x => x.Id == _ctx.UserOfficeRelation.Where(x => x.UserId == u.Id && x.Order == 1).Select(x => x.OfficeId).FirstOrDefault()).Select(x => x.OfficeName).FirstOrDefault(),
                          Secondary_Location = _ctx.OfficeMaster.Where(x => x.Id == _ctx.UserOfficeRelation.Where(x => x.UserId == u.Id && x.Order == 2).Select(x => x.OfficeId).FirstOrDefault()).Select(x => x.OfficeName).FirstOrDefault(),
                          Doc_Contact = u.Doc_Contact,
                          IsActive = (bool)(u.IsActive)
                      }).OrderBy(x => x.CitrixId).ToList();

            IQueryable<RegViewModel> SortedData = result.AsQueryable();

            try
            {
                if (sortColumn == "primary_Location")
                {
                    SortedData = sortColumnDirection == "asc" ? SortedData.OrderBy(s => s.Primary_Location) : SortedData.OrderByDescending(s => sortColumn);
                }
                else if (sortColumn == "userName")
                {
                    SortedData = sortColumnDirection == "asc" ? SortedData.OrderBy(s => s.UserName) : SortedData.OrderByDescending(s => sortColumn);
                }
                else if (sortColumn == "secondary_Location")
                {
                    SortedData = sortColumnDirection == "asc" ? SortedData.OrderBy(s => s.Secondary_Location) : SortedData.OrderByDescending(s => sortColumn);
                }


                //if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                //    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            }
            catch { }


            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = SortedData
            };

            return Json(returnObj);
        }


        // Get OfficeList Data
        [HttpPost]
        public JsonResult GetOfficeList()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

            List<OfficeMaster> result = new List<OfficeMaster>();
            result = (from u in _ctx.OfficeMaster
                      select new OfficeMaster
                      {
                          Office = u.Office,
                          OfficeName = u.OfficeName,

                      }).OrderBy(x => x.OfficeName).ToList();

            IQueryable<OfficeMaster> SortedData = result.AsQueryable();

            int totalRecord = 0;
            int filterRecord = 0;


            var returnObj = new
            {
                data = SortedData
            };

            return Json(returnObj);
        }
        //Get role list
        public JsonResult GetRoleList()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

            List<Role> result = new List<Role>();
            result = (from u in _ctx.Roles
                      select new Role
                      {
                          Role1 = u.Name,

                      }).OrderBy(x => x.Role1).ToList();

            IQueryable<Role> SortedData = result.AsQueryable();

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = SortedData
            };

            return Json(returnObj);
        }
        public IActionResult DocContact()
        {
            return View();
        }

        [HttpPost]
        public JsonResult SaveDocContact([FromBody] ContactPersonModel model)
        {
            string Message = string.Empty;
            try
            {
                if (model.Code == null || model.Code == "" || model.Code == "Name")
                {
                    var found = _ctx.DispositionMaster.Where(x => x.Name == model.Name).FirstOrDefault();

                    if (found == null)
                    {
                        _ctx.DispositionMaster.Add(new DispositionMaster
                        {
                            Name = model.Name,
                        });
                        _ctx.SaveChanges();
                        Message = "Doc contact Added Successfully!";
                    }
                    else
                    {
                        Message = "Doc contact is already inserted.";
                    }
                }
                else
                {
                    var found = _ctx.DispositionMaster.Find(model.Code);
                    _ctx.DispositionMaster.Remove(found);
                    _ctx.SaveChanges();

                    _ctx.DispositionMaster.Add(new DispositionMaster
                    {
                        Name = model.Name,
                    });
                    _ctx.SaveChanges();
                    Message = "Doc contact is update successfully!";
                }
            }
            catch (Exception ex)
            {

            }

            return Json(Message);
        }

        //Get OfficeList Data
        [HttpPost]
        public JsonResult GetdoccontactList()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

            List<DispositionMaster> result = new List<DispositionMaster>();
            result = (from u in _ctx.DispositionMaster
                      select new DispositionMaster
                      {
                          Name = u.Name

                      }).OrderBy(x => x.Name).ToList();

            IQueryable<DispositionMaster> SortedData = result.AsQueryable();

            int totalRecord = 0;
            int filterRecord = 0;


            var returnObj = new
            {
                data = SortedData
            };

            return Json(returnObj);
        }

        //[HttpPost]
        //public JsonResult UpdateDocContact()
        //{
        //    var draw = Request.Form["draw"].FirstOrDefault();
        //    var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
        //    var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

        //    List<DispositionMaster> result = new List<DispositionMaster>();
        //    result = (from u in _ctx.DispositionMaster
        //              select new DispositionMaster
        //              {
        //                  Name = u.Name

        //              }).OrderBy(x => x.Name).ToList();

        //    IQueryable<DispositionMaster> SortedData = result.AsQueryable();

        //    int totalRecord = 0;
        //    int filterRecord = 0;


        //    var returnObj = new
        //    {
        //        data = SortedData
        //    };

        //    return Json(returnObj);
        //}

        //[HttpPost]
        //public IActionResult SaveDocContact([FromBody]  ContactPersonModel model)
        //{
        //    // Check if a Doc Contact with the same name already exists
        //    var existingDocContact = _ctx.DispositionMaster.FirstOrDefault(cp => cp.Name == model.Name);

        //    if (existingDocContact != null)
        //    {
        //        return Json("Doc contact is already inserted.");
        //    }

        //    // Create a new Doc Contact
        //    var newDocContact = new DispositionMaster
        //    {
        //        Name = model.Name,
        //        Code = model.Code
        //    };

        //    // Add and save to the database
        //    _ctx.DispositionMaster.Add(newDocContact);
        //    _ctx.SaveChanges();

        //    return Json("Doc contact Added Successfully!");
        //}

        [HttpPost]
        public IActionResult UpdateDocContact([FromBody]  ContactPersonModel model)
        {

            var existingDocContact = _ctx.DispositionMaster.FirstOrDefault(cp => cp.Name == model.Code);

            // Check if a record with the new primary key already exists
            var existingName = _ctx.DispositionMaster.Any(cp => cp.Name == model.Name);

            if (existingDocContact != null)
            {
                // If a record with the new primary key already exists, return an error message
                if (existingName)
                {
                    return Json("Doc contact is already Exist.");
                }

                // Otherwise, create a new Doc Contact
                var updateDocContact = new DispositionMaster
                {
                    Name = model.Name
                };

                // Add and save to the database
                _ctx.DispositionMaster.Add(updateDocContact);

                // Remove the existing record from the context
                _ctx.DispositionMaster.Remove(existingDocContact);

                _ctx.SaveChanges();

                return Json("Doc contact is updated successfully!");
            }
            else
            {
                return Json("Doc contact not found.");
            }

        }

        [HttpPost]
        public JsonResult IsLDAPActive([FromBody] IsLoginActiveModel model)
        {
            string Msg = "";
            try
            {
                if (model != null)
                {
                    var wnsid = _ctx.Users.Where(x => x.Wnsid == model.UserId).Select(x => x.Wnsid).SingleOrDefault();
                    UserMaster user = _ctx.UserMaster.Where(x => x.Wnsid == wnsid).FirstOrDefault();
                    Boolean status = Convert.ToBoolean(model.IsActive);
                    if (model.IsActive == false)
                    {
                        user.IsLDAP = false;
                        Msg = "LDAP deactivated Sucessfully!..";
                    }
                    else
                    {
                        user.IsLDAP = true;
                        Msg = "LDAP actived Sucessfully!..";
                    }
                    _ctx.UserMaster.Update(user);
                    _ctx.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                Msg = ex.Message;
            }
            return Json(Msg);
        }

        [HttpPost]
        public JsonResult IsResetActive([FromBody] IsLoginActiveModel model)
        {
            string Msg = "";
            var wnsid = _ctx.Users.Where(x => x.Wnsid == model.UserId).Select(x => x.Wnsid).SingleOrDefault();
            UserMaster user = _ctx.UserMaster.Where(x => x.Wnsid == wnsid).FirstOrDefault();
            try
            {
                if (model != null)
                {
                    Boolean status = Convert.ToBoolean(model.IsActive);
                    if (model.IsActive == false)
                    {
                        user.IsReset = false;
                        Msg = "Password set Successfully!..";
                    }
                    else
                    {
                        user.IsReset = true;
                        Msg = "Password reset Successfully!..";
                    }
                    _ctx.UserMaster.Update(user);
                    _ctx.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                Msg = ex.Message;
            }
            return Json(new { Message = Msg, UserName = user.UserName, CitrixId = user.CitrixId, UserId = user.Id });
        }

        [HttpPost]
        public JsonResult IsDeleteActive([FromBody] IsLoginActiveModel model)
        {
            string Msg = "";
            try
            {
                if (model != null)
                {
                    var wnsid = _ctx.Users.Where(x => x.Wnsid == model.UserId).Select(x => x.Wnsid).SingleOrDefault();
                    UserMaster user = _ctx.UserMaster.Where(x => x.Wnsid == wnsid).FirstOrDefault();
                    Boolean status = Convert.ToBoolean(model.IsActive);
                    if (model.IsActive == false)
                    {
                        user.IsDelete = false;
                        Msg = "User restored Sucessfully!..";
                    }
                    else
                    {
                        user.IsDelete = true;
                        Msg = "User deleted Sucessfully!..";
                    }
                    _ctx.UserMaster.Update(user);
                    _ctx.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                Msg = ex.Message;
            }
            return Json(Msg);
        }


        public JsonResult ActivateUser(string Id)
        {
            string message = "";
            if (Id != null)
            {
                UserMaster master = _ctx.UserMaster.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    //master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _ctx.Users.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.UserName + " User Activated!" : master.UserName + " User Deactivated!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }
        public JsonResult DeleteUser(string Id)
        {
            string message = "";
            if (Id != null)
            {
                UserMaster master = _ctx.UserMaster.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _ctx.Users.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.UserName + " User Deleted!" : master.UserName + " User Restore!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }
        public JsonResult ActivateOffice(Guid Id)
        {
            string message = "";
            if (Id != Guid.Empty)
            {
                OfficeMaster master = _ctx.OfficeMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    //master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _ctx.OfficeMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.OfficeName + " Office Activated!" : master.OfficeName + " Office Deactivated!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }
        public JsonResult DeleteOffice(Guid Id)
        {
            string message = "";
            if (Id != Guid.Empty)
            {
                OfficeMaster master = _ctx.OfficeMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    //master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _ctx.OfficeMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsDelete == true ? master.OfficeName + " Office Activated!" : master.OfficeName + " Office Deactivated!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        public JsonResult UpdateIsLDAP(string Id)
        {
            string message = "";
            if (Id != null)
            {
                UserMaster master = _ctx.UserMaster.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsLDAP = master.IsLDAP != null ? !master.IsLDAP : true;
                    _ctx.Users.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsLDAP == true ? master.UserName + " LDAP Active!" : master.UserName + " LDAP InActive!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult UpdateIsReset(string Id)
        {
            string message = "";
            UserMaster master = _ctx.UserMaster.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();

            if (Id != null)
            {
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsReset = master.IsReset != null ? !master.IsReset : true;
                    _ctx.Users.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsReset == true ? master.UserName + " Password Unset!" : master.UserName + " Password Reset!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(new { Message = message, UserName = master.UserName, CitrixId = master.CitrixId, UserId = master.Id });
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpGet]
        public IActionResult RegisterOffice()
        {
            //ViewData["Roles"] = roleManager.Roles.OrderBy(x => x.Name).ToList();
            ViewData["Office"] = _ctx.OfficeMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.OfficeName).ToList();

            //ViewData["Roles"] = _ctx.Roles.Select(x => new RoleManager
            //{
            //	Id = x.Id,
            //	Name = x.Name

            //}).ToList();

            return View();
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpPost]
        public async Task<IActionResult> RegisterOffice(RegisterOfficeViewModel model)
        {
            if (ModelState.IsValid)
            {
                var officeList = _ctx.OfficeMaster.Where(x => x.Id == model.Id && x.IsDelete == true && x.IsDelete == false).OrderBy(x => x.OfficeName).ToList();

                if (officeList == null || officeList.Count == 0)
                {
                    _ctx.OfficeMaster.Add(new OfficeMaster
                    {
                        OfficeName = model.OfficeName,
                        Office = model.Office
                    });

                    _ctx.SaveChanges();

                }
                else
                {
                    return Json("Office already Exist.");
                }
            }

            return Json("success");
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpGet]
        public IActionResult EditOffice(Guid id)
        {
            ViewData["EditOffice"] = _ctx.OfficeMaster.Where(x => x.Id == id && x.IsActive == true && x.IsDelete == false).FirstOrDefault();

            return PartialView();
        }

        [HttpPost]
        public async Task<JsonResult> EditOffice(RegisterOfficeViewModel model)
        {
            var office = _ctx.OfficeMaster.Where(x => x.Id == model.Id && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
            if (office != null)
            {
                office.Office = model.Office.Trim();
                office.OfficeName = model.OfficeName.Trim();
                _ctx.OfficeMaster.Update(office);
                _ctx.SaveChanges();
                return Json("Updated Successfully..!");
            }
            else
            {
                return Json("Error while processing the request");
            }
        }

    }
}

