﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class HBLDetailModel
    {
        public string? FileNumber { get; set; }
        public string Container { get; set; }
        public string Hblno { get; set; }
        public string? hblpod { get; set; }
        public string? hblpld { get; set; }
        public string? hblprostatus { get; set; }
        public DateTime? hblprodate { get; set; }
        public string? hblprodateIST { get; set; }
        public string? hblprocomment { get; set; }
        public string? invoicestatus { get; set; }
        public string? invoicedate { get; set; }
        public string? invoiceDateIST { get; set; }
        public string? invoiceprocomment { get; set; }
        public string? amsstatus { get; set; }
        public DateTime? amsdate { get; set; }
        public string? amsDateIST { get; set; }
        public string? amsprocomment { get; set; }
        public string? HblCompletedBy { get; set; }
        public string? productionDate { get; set; }
        public DateTime? FileComplitionDate { get; set; }
        public string? FileComplitionDateIST { get; set; }
    }
}
