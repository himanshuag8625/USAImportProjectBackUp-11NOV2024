﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class QCReportModel
    {
        public string FileNumber { get; set; }
        public string HblNo { get; set; }
        public string ErrorField { get; set; }
        public string ErrorType { get; set; }
        public string Comment { get; set; }
        public string L1comment { get; set; }       
        public string QcStatus { get; set; }
        public string Qcuser { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string? ProductionDate { get; set; }
    }
}
