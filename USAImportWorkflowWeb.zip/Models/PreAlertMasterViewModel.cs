﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace USAImportWorkflowWeb.Models
{
    public class PreAlertMasterViewModel
    {
        public Guid Id { get; set; }
        public string FileNumber { get; set; }
        public string Container { get; set; }
        public string Mbl { get; set; }
        public int? Hblcount { get; set; }
        public string Pod { get; set; }
        public string Pol { get; set; }
        public DateTime? RecievedDate { get; set; }
        public DateTime? Eta { get; set; }
        public string Office { get; set; }
        public string FileType { get; set; }
        public string ContractPerson { get; set; }
        public string UserId { get; set; }
        public string FuserId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ComplitionTime { get; set; }
        public DateTime? UpdationTime { get; set; }
        public string Status { get; set; }
        public string MissingDoc { get; set; }
        public DateTime? EmailSendDate { get; set; }
        public DateTime? MissDocReceivedDate { get; set; }
        public string AmsCheck { get; set; }
        public string IfsCheck { get; set; }
        public string HazDoc { get; set; }
        public string PieceCount { get; set; }
        public string Priority { get; set; }
        public string Remarks { get; set; }
        public DateTime? ChecklistComplitionDate { get; set; }
    }
    public class PreAlertMasterReport
    {
        public string FileNumber { get; set; }
        public string Container { get; set; }
        public string Mbl { get; set; }
        public int? Hblcount { get; set; }
        public string Pod { get; set; }
        public string Pol { get; set; }
        public DateTime? RecievedDate { get; set; }
        public string? ReceivedDateIST { get; set; }
        public DateTime? Eta { get; set; }       
        public string Status { get; set; }
        public string Priority { get; set; }
        public string Remarks { get; set; }
        public DateTime? ComplitionTime { get; set; }
        public string? CompletionIST { get; set; }
        public string? UserId { get; set; }
        public string? FuserId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? CreatedDateIST { get; set; }
        public string? ProductionDate { get; set; }

    }

}
