﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class PreAlertReportFilter
    {
        public string? Office { get; set; }
        public string? Container { get; set; }
        public string? Status { get; set; }
        public DateTime? Eta { get; set; }
        public string? User { get; set; }
        public string? currentStatus { get; set; }
    }
}
