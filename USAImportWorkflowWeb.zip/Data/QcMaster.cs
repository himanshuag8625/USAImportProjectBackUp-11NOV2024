﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace USAImportWorkflowWeb.Data
{
    public class QcMaster
    {
        public QcMaster()
        {
            QcHblWiseData = new HashSet<QcHblWiseData>();

        }
        public Guid Id { get; set; } = Guid.NewGuid();
        
        public string FileNumber { get; set; }
        public string HblNo { get; set; }
        public string ErrorField { get; set; }
        public string ErrorType { get; set; }
        public string Comment { get; set; }
        public string L1comment { get; set; }
        public string L2comment { get; set; }
        public string L3comment { get; set; }
        public string L4comment { get; set; }
        public string QcStatus { get; set; }
        public string Qcuser { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }


        [ForeignKey("FileNumber")]
        public virtual FileMaster FileMaster { get; set; }
        public virtual ICollection<QcHblWiseData> QcHblWiseData { get; set; }
    }
}
