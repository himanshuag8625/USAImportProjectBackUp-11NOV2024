﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Models
{
    public class RegisterViewModel
    {
		[Required]
		public string UserName { get; set; }

		[Required]
		public string Wnsid { get; set; }

		[Required]
		public string CitrixId { get; set; }

		[Required]
		public string Doc_Contact { get; set; }
		public string Userrole { get; set; }
        public string Primary_Location { get; set; }
		public string Secondary_Location { get; set; }
        public Boolean IsActive { get; set; }
    }
}
