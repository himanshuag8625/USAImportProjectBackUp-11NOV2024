﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace USAImportWorkflowWeb.Models
{
    public class RegisterUserViewModel
    {
        //[Required]
        public string? Id { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string? EmpId { get; set; } 
        public Guid? Primary_Location { get; set; }
        public Guid? Secondary_Location { get; set; }
        public string? Doc_Contact { get; set; }
        [Required]
        public string? CitrixId { get; set; }
        public string? Role { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDelete { get; set; }
        public bool? IsLDAP { get; set; }
        public bool? IsReset { get; set; }
        public List<IdentityRole>? RoleList { get; set; }
        public List<string>? assingedRoleList { get; set; }
    }
}
