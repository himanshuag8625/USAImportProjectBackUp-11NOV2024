﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class QCDashboardReport
    {
        public string? FileNumber { get; set; }
        public string? Pod { get; set; }
        public string? QcStatus { get; set; }
        public string? currentStatus { get; set; }
        public string? Icuser { get; set; }
        public DateTime? Eta { get; set; }
    }
}
