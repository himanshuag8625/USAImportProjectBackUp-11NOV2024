﻿namespace USAImportWorkflowWeb.Models
{
    public class QcDashboardCount
    {
        public int Received { get; set; }
        public int WIP { get; set; }
        public int Pending { get; set; }
        public int Completed { get; set; }
        public int OnHold { get; set; }
        public int ETA10 { get; set; }
        public int ETA12 { get; set; }
    }
}
