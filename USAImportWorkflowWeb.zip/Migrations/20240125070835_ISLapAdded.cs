﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace USAImportWorkflowWeb.Migrations
{
    public partial class ISLapAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "DispositionMaster",
                columns: table => new
                {
                    Name = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Code = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DispositionMaster", x => x.Name);
                });

            migrationBuilder.CreateTable(
                name: "DocContactMaster",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ContactPerson = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocContactMaster", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "OfficeMaster",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Office = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OfficeName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OfficeMaster", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Role",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Role", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "User",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    Wnsid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CitrixId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Doc_Contact = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false),
                    IsLDAP = table.Column<bool>(type: "bit", nullable: false),
                    IsReset = table.Column<bool>(type: "bit", nullable: false),
                    NormalizedUserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    SecurityStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AccessFailedCount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UserOfficeRelation",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    UserId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OfficeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Order = table.Column<int>(type: "int", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserOfficeRelation", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RoleClaims_Role_RoleId",
                        column: x => x.RoleId,
                        principalTable: "Role",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Digiview",
                columns: table => new
                {
                    Hblno = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    DigiviewStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DigiviewComments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Digiview", x => x.Hblno);
                    table.ForeignKey(
                        name: "FK_Digiview_User_UserId",
                        column: x => x.UserId,
                        principalTable: "User",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "FileMaster",
                columns: table => new
                {
                    FileNumber = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Container = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Mbl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MasterBl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Hblcount = table.Column<int>(type: "int", nullable: true),
                    Pol = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SSL = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Pod = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UnitDispo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DepFile = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ShippingLine = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cfs = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Vessel = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Terminal = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Sslremarks = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NewEta = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DischargeDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    BerthingDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    TrackNtraceUserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    RecievedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Eta = table.Column<DateTime>(type: "datetime2", nullable: true),
                    PreviousEta = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Office = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FileType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContactPerson = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    CreateDateTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Hbluser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Hblstatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DigiviewUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DigiviewStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Icuser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Icstatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Aging = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FileStartTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    FileComplitionDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EtaChangedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EtaChangedComment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EtaChangedDatetime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    QcStatus = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FileMaster", x => x.FileNumber);
                    table.ForeignKey(
                        name: "FK_FileMaster_User_TrackNtraceUserId",
                        column: x => x.TrackNtraceUserId,
                        principalTable: "User",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_FileMaster_User_UserId",
                        column: x => x.UserId,
                        principalTable: "User",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "PreAlertMaster",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FileNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Container = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Mbl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Hblcount = table.Column<int>(type: "int", nullable: true),
                    Pod = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Pol = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RecievedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Eta = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Office = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FileType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContractPerson = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    FuserId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ComplitionTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MissingDoc = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmailSendDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    MissDocReceivedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AmsCheck = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IfsCheck = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HazDoc = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PieceCount = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Priority = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ChecklistComplitionDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PreAlertMaster", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PreAlertMaster_User_UserId",
                        column: x => x.UserId,
                        principalTable: "User",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "UserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_UserClaims_User_UserId",
                        column: x => x.UserId,
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderKey = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_UserLogins_User_UserId",
                        column: x => x.UserId,
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UserOfficeMaster",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    OfficeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    LocationNameNavigationId = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserOfficeMaster", x => x.Id);
                    table.ForeignKey(
                        name: "FK_UserOfficeMaster_OfficeMaster_LocationNameNavigationId",
                        column: x => x.LocationNameNavigationId,
                        principalTable: "OfficeMaster",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_UserOfficeMaster_User_UserId",
                        column: x => x.UserId,
                        principalTable: "User",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "UserRoles",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_UserRoles_Role_RoleId",
                        column: x => x.RoleId,
                        principalTable: "Role",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserRoles_User_UserId",
                        column: x => x.UserId,
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UserTokens",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_UserTokens_User_UserId",
                        column: x => x.UserId,
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "HBLMaster",
                columns: table => new
                {
                    Hblno = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Pod = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Pld = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FileNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    HblprocessingStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HblprocessingDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Hblcomments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Amsstatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AmsprocessingDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Amscomments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InvoicingStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InvoicingDate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InvoicingComments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DigiviewUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DigiviewStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DigiviewComments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FileMasterFileNumber = table.Column<string>(type: "nvarchar(20)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HBLMaster", x => x.Hblno);
                    table.ForeignKey(
                        name: "FK_HBLMaster_FileMaster_FileMasterFileNumber",
                        column: x => x.FileMasterFileNumber,
                        principalTable: "FileMaster",
                        principalColumn: "FileNumber");
                });

            migrationBuilder.CreateTable(
                name: "QcMaster",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FileNumber = table.Column<string>(type: "nvarchar(20)", nullable: true),
                    HblNo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ErrorField = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ErrorType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    L1comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    L2comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    L3comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    L4comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    QcStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Qcuser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StartTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QcMaster", x => x.Id);
                    table.ForeignKey(
                        name: "FK_QcMaster_FileMaster_FileNumber",
                        column: x => x.FileNumber,
                        principalTable: "FileMaster",
                        principalColumn: "FileNumber");
                });

            migrationBuilder.CreateTable(
                name: "HBLProcessing",
                columns: table => new
                {
                    ActivtyId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Hblno = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Activity = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ActivityStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UpdateDatetime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    HblnoNavigationHblno = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HBLProcessing", x => x.ActivtyId);
                    table.ForeignKey(
                        name: "FK_HBLProcessing_HBLMaster_HblnoNavigationHblno",
                        column: x => x.HblnoNavigationHblno,
                        principalTable: "HBLMaster",
                        principalColumn: "Hblno");
                });

            migrationBuilder.CreateTable(
                name: "ImportCoOrdinator",
                columns: table => new
                {
                    ActivityID = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Hblno = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Activity = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ActivityStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ActivityComment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    LastUpdateDateTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    HblnoNavigationHblno = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ImportCoOrdinator", x => x.ActivityID);
                    table.ForeignKey(
                        name: "FK_ImportCoOrdinator_HBLMaster_HblnoNavigationHblno",
                        column: x => x.HblnoNavigationHblno,
                        principalTable: "HBLMaster",
                        principalColumn: "Hblno");
                    table.ForeignKey(
                        name: "FK_ImportCoOrdinator_User_UserId",
                        column: x => x.UserId,
                        principalTable: "User",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "QcHblWiseData",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    QcMasterId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    FileNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Hblno = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ErrorField = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ErrorType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    L1comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    L2comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    L3comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    L4comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    QcStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Qcuser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StartTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QcHblWiseData", x => x.Id);
                    table.ForeignKey(
                        name: "FK_QcHblWiseData_QcMaster_QcMasterId",
                        column: x => x.QcMasterId,
                        principalTable: "QcMaster",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Digiview_UserId",
                table: "Digiview",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_FileMaster_TrackNtraceUserId",
                table: "FileMaster",
                column: "TrackNtraceUserId");

            migrationBuilder.CreateIndex(
                name: "IX_FileMaster_UserId",
                table: "FileMaster",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_HBLMaster_FileMasterFileNumber",
                table: "HBLMaster",
                column: "FileMasterFileNumber");

            migrationBuilder.CreateIndex(
                name: "IX_HBLProcessing_HblnoNavigationHblno",
                table: "HBLProcessing",
                column: "HblnoNavigationHblno");

            migrationBuilder.CreateIndex(
                name: "IX_ImportCoOrdinator_HblnoNavigationHblno",
                table: "ImportCoOrdinator",
                column: "HblnoNavigationHblno");

            migrationBuilder.CreateIndex(
                name: "IX_ImportCoOrdinator_UserId",
                table: "ImportCoOrdinator",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_PreAlertMaster_UserId",
                table: "PreAlertMaster",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_QcHblWiseData_QcMasterId",
                table: "QcHblWiseData",
                column: "QcMasterId");

            migrationBuilder.CreateIndex(
                name: "IX_QcMaster_FileNumber",
                table: "QcMaster",
                column: "FileNumber");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "Role",
                column: "NormalizedName",
                unique: true,
                filter: "[NormalizedName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_RoleClaims_RoleId",
                table: "RoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "User",
                column: "NormalizedUserName",
                unique: true,
                filter: "[NormalizedUserName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_UserClaims_UserId",
                table: "UserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_UserLogins_UserId",
                table: "UserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_UserOfficeMaster_LocationNameNavigationId",
                table: "UserOfficeMaster",
                column: "LocationNameNavigationId");

            migrationBuilder.CreateIndex(
                name: "IX_UserOfficeMaster_UserId",
                table: "UserOfficeMaster",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_UserRoles_RoleId",
                table: "UserRoles",
                column: "RoleId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Digiview");

            migrationBuilder.DropTable(
                name: "DispositionMaster");

            migrationBuilder.DropTable(
                name: "DocContactMaster");

            migrationBuilder.DropTable(
                name: "HBLProcessing");

            migrationBuilder.DropTable(
                name: "ImportCoOrdinator");

            migrationBuilder.DropTable(
                name: "PreAlertMaster");

            migrationBuilder.DropTable(
                name: "QcHblWiseData");

            migrationBuilder.DropTable(
                name: "RoleClaims");

            migrationBuilder.DropTable(
                name: "UserClaims");

            migrationBuilder.DropTable(
                name: "UserLogins");

            migrationBuilder.DropTable(
                name: "UserOfficeMaster");

            migrationBuilder.DropTable(
                name: "UserOfficeRelation");

            migrationBuilder.DropTable(
                name: "UserRoles");

            migrationBuilder.DropTable(
                name: "UserTokens");

            migrationBuilder.DropTable(
                name: "HBLMaster");

            migrationBuilder.DropTable(
                name: "QcMaster");

            migrationBuilder.DropTable(
                name: "OfficeMaster");

            migrationBuilder.DropTable(
                name: "Role");

            migrationBuilder.DropTable(
                name: "FileMaster");

            migrationBuilder.DropTable(
                name: "User");
        }
    }
}
